﻿
namespace University_Management_System
{
    partial class Teacher_dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.Back_Button = new System.Windows.Forms.Button();
            this.Profile_link = new System.Windows.Forms.LinkLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.course6 = new System.Windows.Forms.Label();
            this.room6 = new System.Windows.Forms.Label();
            this.time6 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.course5 = new System.Windows.Forms.Label();
            this.room5 = new System.Windows.Forms.Label();
            this.time5 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.course4 = new System.Windows.Forms.Label();
            this.room4 = new System.Windows.Forms.Label();
            this.time4 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.course3 = new System.Windows.Forms.Label();
            this.room3 = new System.Windows.Forms.Label();
            this.time3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.course2 = new System.Windows.Forms.Label();
            this.room2 = new System.Windows.Forms.Label();
            this.time2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.course1 = new System.Windows.Forms.Label();
            this.room1 = new System.Windows.Forms.Label();
            this.time1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Wednesday_panel = new System.Windows.Forms.Panel();
            this.linkwednesday5 = new System.Windows.Forms.LinkLabel();
            this.Wednesday = new System.Windows.Forms.Label();
            this.linkwednesday4 = new System.Windows.Forms.LinkLabel();
            this.linkwednesday3 = new System.Windows.Forms.LinkLabel();
            this.linkwednesday1 = new System.Windows.Forms.LinkLabel();
            this.linkwednesday2 = new System.Windows.Forms.LinkLabel();
            this.Tuesday_panel = new System.Windows.Forms.Panel();
            this.linkTuesday5 = new System.Windows.Forms.LinkLabel();
            this.linkTuesday4 = new System.Windows.Forms.LinkLabel();
            this.linkTuesday3 = new System.Windows.Forms.LinkLabel();
            this.linkTuesday2 = new System.Windows.Forms.LinkLabel();
            this.linkTuesday1 = new System.Windows.Forms.LinkLabel();
            this.Tuesday = new System.Windows.Forms.Label();
            this.Monday_panel = new System.Windows.Forms.Panel();
            this.linkMonday5 = new System.Windows.Forms.LinkLabel();
            this.linkMonday4 = new System.Windows.Forms.LinkLabel();
            this.linkMonday3 = new System.Windows.Forms.LinkLabel();
            this.linkMonday2 = new System.Windows.Forms.LinkLabel();
            this.linkMonday1 = new System.Windows.Forms.LinkLabel();
            this.Monday = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Sunday_panel = new System.Windows.Forms.Panel();
            this.linkSunday5 = new System.Windows.Forms.LinkLabel();
            this.linkSunday4 = new System.Windows.Forms.LinkLabel();
            this.linkSunday3 = new System.Windows.Forms.LinkLabel();
            this.linkSunday2 = new System.Windows.Forms.LinkLabel();
            this.linkSunday1 = new System.Windows.Forms.LinkLabel();
            this.Sunday = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.Wednesday_panel.SuspendLayout();
            this.Tuesday_panel.SuspendLayout();
            this.Monday_panel.SuspendLayout();
            this.Sunday_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.AutoScroll = true;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.Back_Button);
            this.panel2.Controls.Add(this.Profile_link);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.Wednesday_panel);
            this.panel2.Controls.Add(this.Tuesday_panel);
            this.panel2.Controls.Add(this.Monday_panel);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Sunday_panel);
            this.panel2.Location = new System.Drawing.Point(228, 26);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(979, 851);
            this.panel2.TabIndex = 2;
            // 
            // Back_Button
            // 
            this.Back_Button.BackgroundImage = global::University_Management_System.Properties.Resources.backButton2;
            this.Back_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Back_Button.Location = new System.Drawing.Point(903, -1);
            this.Back_Button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Back_Button.Name = "Back_Button";
            this.Back_Button.Size = new System.Drawing.Size(63, 52);
            this.Back_Button.TabIndex = 8;
            this.Back_Button.UseVisualStyleBackColor = true;
            this.Back_Button.Click += new System.EventHandler(this.Back_Button_Click);
            // 
            // Profile_link
            // 
            this.Profile_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Profile_link.AutoSize = true;
            this.Profile_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Profile_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Profile_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Profile_link.Location = new System.Drawing.Point(622, 16);
            this.Profile_link.Name = "Profile_link";
            this.Profile_link.Size = new System.Drawing.Size(66, 25);
            this.Profile_link.TabIndex = 13;
            this.Profile_link.TabStop = true;
            this.Profile_link.Text = "Profile";
            this.Profile_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Profile_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Profile_link_LinkClicked);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(7, 355);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(959, 492);
            this.panel3.TabIndex = 2;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.course6);
            this.panel10.Controls.Add(this.room6);
            this.panel10.Controls.Add(this.time6);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Location = new System.Drawing.Point(643, 270);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(311, 215);
            this.panel10.TabIndex = 5;
            // 
            // course6
            // 
            this.course6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course6.Location = new System.Drawing.Point(11, 16);
            this.course6.Name = "course6";
            this.course6.Size = new System.Drawing.Size(295, 75);
            this.course6.TabIndex = 7;
            this.course6.Text = " ";
            // 
            // room6
            // 
            this.room6.AutoSize = true;
            this.room6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room6.Location = new System.Drawing.Point(22, 128);
            this.room6.Name = "room6";
            this.room6.Size = new System.Drawing.Size(71, 24);
            this.room6.TabIndex = 3;
            this.room6.Text = "Room:-";
            // 
            // time6
            // 
            this.time6.AutoSize = true;
            this.time6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time6.Location = new System.Drawing.Point(25, 174);
            this.time6.Name = "time6";
            this.time6.Size = new System.Drawing.Size(68, 24);
            this.time6.TabIndex = 2;
            this.time6.Text = " Time:-";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(3, 115);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(303, 95);
            this.label26.TabIndex = 1;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.course5);
            this.panel9.Controls.Add(this.room5);
            this.panel9.Controls.Add(this.time5);
            this.panel9.Controls.Add(this.label22);
            this.panel9.Location = new System.Drawing.Point(323, 270);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(311, 215);
            this.panel9.TabIndex = 7;
            // 
            // course5
            // 
            this.course5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course5.Location = new System.Drawing.Point(11, 0);
            this.course5.Name = "course5";
            this.course5.Size = new System.Drawing.Size(295, 75);
            this.course5.TabIndex = 6;
            this.course5.Text = " ";
            this.course5.Click += new System.EventHandler(this.course5_Click);
            // 
            // room5
            // 
            this.room5.AutoSize = true;
            this.room5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room5.Location = new System.Drawing.Point(15, 128);
            this.room5.Name = "room5";
            this.room5.Size = new System.Drawing.Size(71, 24);
            this.room5.TabIndex = 3;
            this.room5.Text = "Room:-";
            // 
            // time5
            // 
            this.time5.AutoSize = true;
            this.time5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time5.Location = new System.Drawing.Point(21, 174);
            this.time5.Name = "time5";
            this.time5.Size = new System.Drawing.Size(68, 24);
            this.time5.TabIndex = 2;
            this.time5.Text = " Time:-";
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(3, 115);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(303, 95);
            this.label22.TabIndex = 1;
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.course4);
            this.panel8.Controls.Add(this.room4);
            this.panel8.Controls.Add(this.time4);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Location = new System.Drawing.Point(3, 270);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(311, 215);
            this.panel8.TabIndex = 6;
            // 
            // course4
            // 
            this.course4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course4.Location = new System.Drawing.Point(11, 16);
            this.course4.Name = "course4";
            this.course4.Size = new System.Drawing.Size(295, 75);
            this.course4.TabIndex = 7;
            this.course4.Text = " ";
            // 
            // room4
            // 
            this.room4.AutoSize = true;
            this.room4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room4.Location = new System.Drawing.Point(25, 128);
            this.room4.Name = "room4";
            this.room4.Size = new System.Drawing.Size(71, 24);
            this.room4.TabIndex = 3;
            this.room4.Text = "Room:-";
            // 
            // time4
            // 
            this.time4.AutoSize = true;
            this.time4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time4.Location = new System.Drawing.Point(25, 174);
            this.time4.Name = "time4";
            this.time4.Size = new System.Drawing.Size(68, 24);
            this.time4.TabIndex = 2;
            this.time4.Text = " Time:-";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(3, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(303, 95);
            this.label18.TabIndex = 1;
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.course3);
            this.panel7.Controls.Add(this.room3);
            this.panel7.Controls.Add(this.time3);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Location = new System.Drawing.Point(643, 50);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(311, 215);
            this.panel7.TabIndex = 5;
            // 
            // course3
            // 
            this.course3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course3.Location = new System.Drawing.Point(7, 12);
            this.course3.Name = "course3";
            this.course3.Size = new System.Drawing.Size(299, 75);
            this.course3.TabIndex = 6;
            // 
            // room3
            // 
            this.room3.AutoSize = true;
            this.room3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room3.Location = new System.Drawing.Point(19, 128);
            this.room3.Name = "room3";
            this.room3.Size = new System.Drawing.Size(71, 24);
            this.room3.TabIndex = 3;
            this.room3.Text = "Room:-";
            // 
            // time3
            // 
            this.time3.AutoSize = true;
            this.time3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time3.Location = new System.Drawing.Point(22, 174);
            this.time3.Name = "time3";
            this.time3.Size = new System.Drawing.Size(68, 24);
            this.time3.TabIndex = 2;
            this.time3.Text = " Time:-";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(3, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(303, 99);
            this.label14.TabIndex = 1;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.course2);
            this.panel6.Controls.Add(this.room2);
            this.panel6.Controls.Add(this.time2);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Location = new System.Drawing.Point(323, 50);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(311, 215);
            this.panel6.TabIndex = 4;
            // 
            // course2
            // 
            this.course2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course2.Location = new System.Drawing.Point(7, 12);
            this.course2.Name = "course2";
            this.course2.Size = new System.Drawing.Size(299, 75);
            this.course2.TabIndex = 5;
            // 
            // room2
            // 
            this.room2.AutoSize = true;
            this.room2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room2.Location = new System.Drawing.Point(18, 128);
            this.room2.Name = "room2";
            this.room2.Size = new System.Drawing.Size(71, 24);
            this.room2.TabIndex = 3;
            this.room2.Text = "Room:-";
            // 
            // time2
            // 
            this.time2.AutoSize = true;
            this.time2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time2.Location = new System.Drawing.Point(18, 174);
            this.time2.Name = "time2";
            this.time2.Size = new System.Drawing.Size(68, 24);
            this.time2.TabIndex = 2;
            this.time2.Text = " Time:-";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(3, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(303, 99);
            this.label10.TabIndex = 1;
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.course1);
            this.panel5.Controls.Add(this.room1);
            this.panel5.Controls.Add(this.time1);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(3, 50);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(311, 215);
            this.panel5.TabIndex = 3;
            // 
            // course1
            // 
            this.course1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course1.Location = new System.Drawing.Point(7, 12);
            this.course1.Name = "course1";
            this.course1.Size = new System.Drawing.Size(299, 75);
            this.course1.TabIndex = 4;
            this.course1.Text = " ";
            // 
            // room1
            // 
            this.room1.AutoSize = true;
            this.room1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room1.Location = new System.Drawing.Point(25, 128);
            this.room1.Name = "room1";
            this.room1.Size = new System.Drawing.Size(71, 24);
            this.room1.TabIndex = 3;
            this.room1.Text = "Room:-";
            // 
            // time1
            // 
            this.time1.AutoSize = true;
            this.time1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time1.Location = new System.Drawing.Point(25, 174);
            this.time1.Name = "time1";
            this.time1.Size = new System.Drawing.Size(68, 24);
            this.time1.TabIndex = 2;
            this.time1.Text = " Time:-";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.CornflowerBlue;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(303, 99);
            this.label3.TabIndex = 1;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.comboBox1);
            this.panel4.Location = new System.Drawing.Point(3, 2);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(951, 41);
            this.panel4.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(677, 6);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(269, 28);
            this.comboBox1.TabIndex = 3;
            // 
            // Wednesday_panel
            // 
            this.Wednesday_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wednesday_panel.Controls.Add(this.linkwednesday5);
            this.Wednesday_panel.Controls.Add(this.Wednesday);
            this.Wednesday_panel.Controls.Add(this.linkwednesday4);
            this.Wednesday_panel.Controls.Add(this.linkwednesday3);
            this.Wednesday_panel.Controls.Add(this.linkwednesday1);
            this.Wednesday_panel.Controls.Add(this.linkwednesday2);
            this.Wednesday_panel.Location = new System.Drawing.Point(492, 206);
            this.Wednesday_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Wednesday_panel.Name = "Wednesday_panel";
            this.Wednesday_panel.Size = new System.Drawing.Size(474, 148);
            this.Wednesday_panel.TabIndex = 1;
            // 
            // linkwednesday5
            // 
            this.linkwednesday5.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkwednesday5.AutoSize = true;
            this.linkwednesday5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkwednesday5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkwednesday5.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkwednesday5.Location = new System.Drawing.Point(3, 124);
            this.linkwednesday5.Name = "linkwednesday5";
            this.linkwednesday5.Size = new System.Drawing.Size(40, 17);
            this.linkwednesday5.TabIndex = 17;
            this.linkwednesday5.TabStop = true;
            this.linkwednesday5.Text = "Sec5";
            this.linkwednesday5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Wednesday
            // 
            this.Wednesday.AutoSize = true;
            this.Wednesday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Wednesday.Location = new System.Drawing.Point(174, 0);
            this.Wednesday.Name = "Wednesday";
            this.Wednesday.Size = new System.Drawing.Size(107, 24);
            this.Wednesday.TabIndex = 0;
            this.Wednesday.Text = "Wednesday";
            // 
            // linkwednesday4
            // 
            this.linkwednesday4.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkwednesday4.AutoSize = true;
            this.linkwednesday4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkwednesday4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkwednesday4.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkwednesday4.Location = new System.Drawing.Point(3, 99);
            this.linkwednesday4.Name = "linkwednesday4";
            this.linkwednesday4.Size = new System.Drawing.Size(40, 17);
            this.linkwednesday4.TabIndex = 16;
            this.linkwednesday4.TabStop = true;
            this.linkwednesday4.Text = "Sec4";
            this.linkwednesday4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkwednesday3
            // 
            this.linkwednesday3.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkwednesday3.AutoSize = true;
            this.linkwednesday3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkwednesday3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkwednesday3.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkwednesday3.Location = new System.Drawing.Point(3, 74);
            this.linkwednesday3.Name = "linkwednesday3";
            this.linkwednesday3.Size = new System.Drawing.Size(40, 17);
            this.linkwednesday3.TabIndex = 15;
            this.linkwednesday3.TabStop = true;
            this.linkwednesday3.Text = "Sec3";
            this.linkwednesday3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkwednesday1
            // 
            this.linkwednesday1.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkwednesday1.AutoSize = true;
            this.linkwednesday1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkwednesday1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkwednesday1.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkwednesday1.Location = new System.Drawing.Point(3, 24);
            this.linkwednesday1.Name = "linkwednesday1";
            this.linkwednesday1.Size = new System.Drawing.Size(40, 17);
            this.linkwednesday1.TabIndex = 13;
            this.linkwednesday1.TabStop = true;
            this.linkwednesday1.Text = "Sec1";
            this.linkwednesday1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkwednesday2
            // 
            this.linkwednesday2.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkwednesday2.AutoSize = true;
            this.linkwednesday2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkwednesday2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkwednesday2.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkwednesday2.Location = new System.Drawing.Point(3, 49);
            this.linkwednesday2.Name = "linkwednesday2";
            this.linkwednesday2.Size = new System.Drawing.Size(40, 17);
            this.linkwednesday2.TabIndex = 14;
            this.linkwednesday2.TabStop = true;
            this.linkwednesday2.Text = "Sec2";
            this.linkwednesday2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tuesday_panel
            // 
            this.Tuesday_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Tuesday_panel.Controls.Add(this.linkTuesday5);
            this.Tuesday_panel.Controls.Add(this.linkTuesday4);
            this.Tuesday_panel.Controls.Add(this.linkTuesday3);
            this.Tuesday_panel.Controls.Add(this.linkTuesday2);
            this.Tuesday_panel.Controls.Add(this.linkTuesday1);
            this.Tuesday_panel.Controls.Add(this.Tuesday);
            this.Tuesday_panel.Location = new System.Drawing.Point(7, 206);
            this.Tuesday_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Tuesday_panel.Name = "Tuesday_panel";
            this.Tuesday_panel.Size = new System.Drawing.Size(479, 148);
            this.Tuesday_panel.TabIndex = 1;
            // 
            // linkTuesday5
            // 
            this.linkTuesday5.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkTuesday5.AutoSize = true;
            this.linkTuesday5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTuesday5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkTuesday5.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkTuesday5.Location = new System.Drawing.Point(4, 124);
            this.linkTuesday5.Name = "linkTuesday5";
            this.linkTuesday5.Size = new System.Drawing.Size(40, 17);
            this.linkTuesday5.TabIndex = 12;
            this.linkTuesday5.TabStop = true;
            this.linkTuesday5.Text = "Sec5";
            this.linkTuesday5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkTuesday4
            // 
            this.linkTuesday4.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkTuesday4.AutoSize = true;
            this.linkTuesday4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTuesday4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkTuesday4.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkTuesday4.Location = new System.Drawing.Point(4, 99);
            this.linkTuesday4.Name = "linkTuesday4";
            this.linkTuesday4.Size = new System.Drawing.Size(40, 17);
            this.linkTuesday4.TabIndex = 11;
            this.linkTuesday4.TabStop = true;
            this.linkTuesday4.Text = "Sec4";
            this.linkTuesday4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkTuesday3
            // 
            this.linkTuesday3.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkTuesday3.AutoSize = true;
            this.linkTuesday3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTuesday3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkTuesday3.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkTuesday3.Location = new System.Drawing.Point(4, 74);
            this.linkTuesday3.Name = "linkTuesday3";
            this.linkTuesday3.Size = new System.Drawing.Size(40, 17);
            this.linkTuesday3.TabIndex = 10;
            this.linkTuesday3.TabStop = true;
            this.linkTuesday3.Text = "Sec3";
            this.linkTuesday3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkTuesday2
            // 
            this.linkTuesday2.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkTuesday2.AutoSize = true;
            this.linkTuesday2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTuesday2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkTuesday2.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkTuesday2.Location = new System.Drawing.Point(4, 49);
            this.linkTuesday2.Name = "linkTuesday2";
            this.linkTuesday2.Size = new System.Drawing.Size(40, 17);
            this.linkTuesday2.TabIndex = 9;
            this.linkTuesday2.TabStop = true;
            this.linkTuesday2.Text = "Sec2";
            this.linkTuesday2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkTuesday1
            // 
            this.linkTuesday1.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkTuesday1.AutoSize = true;
            this.linkTuesday1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkTuesday1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkTuesday1.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkTuesday1.Location = new System.Drawing.Point(4, 24);
            this.linkTuesday1.Name = "linkTuesday1";
            this.linkTuesday1.Size = new System.Drawing.Size(40, 17);
            this.linkTuesday1.TabIndex = 8;
            this.linkTuesday1.TabStop = true;
            this.linkTuesday1.Text = "Sec1";
            this.linkTuesday1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tuesday
            // 
            this.Tuesday.AutoSize = true;
            this.Tuesday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tuesday.Location = new System.Drawing.Point(182, -1);
            this.Tuesday.Name = "Tuesday";
            this.Tuesday.Size = new System.Drawing.Size(78, 24);
            this.Tuesday.TabIndex = 0;
            this.Tuesday.Text = "Tuesday";
            // 
            // Monday_panel
            // 
            this.Monday_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Monday_panel.Controls.Add(this.linkMonday5);
            this.Monday_panel.Controls.Add(this.linkMonday4);
            this.Monday_panel.Controls.Add(this.linkMonday3);
            this.Monday_panel.Controls.Add(this.linkMonday2);
            this.Monday_panel.Controls.Add(this.linkMonday1);
            this.Monday_panel.Controls.Add(this.Monday);
            this.Monday_panel.Location = new System.Drawing.Point(492, 53);
            this.Monday_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Monday_panel.Name = "Monday_panel";
            this.Monday_panel.Size = new System.Drawing.Size(474, 149);
            this.Monday_panel.TabIndex = 1;
            // 
            // linkMonday5
            // 
            this.linkMonday5.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkMonday5.AutoSize = true;
            this.linkMonday5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkMonday5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkMonday5.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkMonday5.Location = new System.Drawing.Point(3, 124);
            this.linkMonday5.Name = "linkMonday5";
            this.linkMonday5.Size = new System.Drawing.Size(40, 17);
            this.linkMonday5.TabIndex = 12;
            this.linkMonday5.TabStop = true;
            this.linkMonday5.Text = "Sec5";
            this.linkMonday5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkMonday4
            // 
            this.linkMonday4.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkMonday4.AutoSize = true;
            this.linkMonday4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkMonday4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkMonday4.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkMonday4.Location = new System.Drawing.Point(3, 99);
            this.linkMonday4.Name = "linkMonday4";
            this.linkMonday4.Size = new System.Drawing.Size(40, 17);
            this.linkMonday4.TabIndex = 11;
            this.linkMonday4.TabStop = true;
            this.linkMonday4.Text = "Sec4";
            this.linkMonday4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkMonday3
            // 
            this.linkMonday3.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkMonday3.AutoSize = true;
            this.linkMonday3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkMonday3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkMonday3.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkMonday3.Location = new System.Drawing.Point(3, 74);
            this.linkMonday3.Name = "linkMonday3";
            this.linkMonday3.Size = new System.Drawing.Size(40, 17);
            this.linkMonday3.TabIndex = 10;
            this.linkMonday3.TabStop = true;
            this.linkMonday3.Text = "Sec3";
            this.linkMonday3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkMonday2
            // 
            this.linkMonday2.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkMonday2.AutoSize = true;
            this.linkMonday2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkMonday2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkMonday2.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkMonday2.Location = new System.Drawing.Point(3, 49);
            this.linkMonday2.Name = "linkMonday2";
            this.linkMonday2.Size = new System.Drawing.Size(40, 17);
            this.linkMonday2.TabIndex = 9;
            this.linkMonday2.TabStop = true;
            this.linkMonday2.Text = "Sec2";
            this.linkMonday2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkMonday1
            // 
            this.linkMonday1.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkMonday1.AutoSize = true;
            this.linkMonday1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkMonday1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkMonday1.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkMonday1.Location = new System.Drawing.Point(3, 24);
            this.linkMonday1.Name = "linkMonday1";
            this.linkMonday1.Size = new System.Drawing.Size(40, 17);
            this.linkMonday1.TabIndex = 8;
            this.linkMonday1.TabStop = true;
            this.linkMonday1.Text = "Sec1";
            this.linkMonday1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Monday
            // 
            this.Monday.AutoSize = true;
            this.Monday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Monday.Location = new System.Drawing.Point(182, 0);
            this.Monday.Name = "Monday";
            this.Monday.Size = new System.Drawing.Size(79, 24);
            this.Monday.TabIndex = 0;
            this.Monday.Text = "Monday";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(959, 51);
            this.label1.TabIndex = 0;
            this.label1.Text = "   Class Schedul";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sunday_panel
            // 
            this.Sunday_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sunday_panel.Controls.Add(this.linkSunday5);
            this.Sunday_panel.Controls.Add(this.linkSunday4);
            this.Sunday_panel.Controls.Add(this.linkSunday3);
            this.Sunday_panel.Controls.Add(this.linkSunday2);
            this.Sunday_panel.Controls.Add(this.linkSunday1);
            this.Sunday_panel.Controls.Add(this.Sunday);
            this.Sunday_panel.Location = new System.Drawing.Point(7, 53);
            this.Sunday_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Sunday_panel.Name = "Sunday_panel";
            this.Sunday_panel.Size = new System.Drawing.Size(479, 148);
            this.Sunday_panel.TabIndex = 0;
            // 
            // linkSunday5
            // 
            this.linkSunday5.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkSunday5.AutoSize = true;
            this.linkSunday5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkSunday5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkSunday5.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkSunday5.Location = new System.Drawing.Point(3, 124);
            this.linkSunday5.Name = "linkSunday5";
            this.linkSunday5.Size = new System.Drawing.Size(40, 17);
            this.linkSunday5.TabIndex = 7;
            this.linkSunday5.TabStop = true;
            this.linkSunday5.Text = "Sec5";
            this.linkSunday5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkSunday4
            // 
            this.linkSunday4.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkSunday4.AutoSize = true;
            this.linkSunday4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkSunday4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkSunday4.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkSunday4.Location = new System.Drawing.Point(3, 99);
            this.linkSunday4.Name = "linkSunday4";
            this.linkSunday4.Size = new System.Drawing.Size(40, 17);
            this.linkSunday4.TabIndex = 6;
            this.linkSunday4.TabStop = true;
            this.linkSunday4.Text = "Sec4";
            this.linkSunday4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkSunday3
            // 
            this.linkSunday3.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkSunday3.AutoSize = true;
            this.linkSunday3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkSunday3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkSunday3.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkSunday3.Location = new System.Drawing.Point(3, 74);
            this.linkSunday3.Name = "linkSunday3";
            this.linkSunday3.Size = new System.Drawing.Size(40, 17);
            this.linkSunday3.TabIndex = 5;
            this.linkSunday3.TabStop = true;
            this.linkSunday3.Text = "Sec3";
            this.linkSunday3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkSunday2
            // 
            this.linkSunday2.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkSunday2.AutoSize = true;
            this.linkSunday2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkSunday2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkSunday2.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkSunday2.Location = new System.Drawing.Point(3, 49);
            this.linkSunday2.Name = "linkSunday2";
            this.linkSunday2.Size = new System.Drawing.Size(40, 17);
            this.linkSunday2.TabIndex = 4;
            this.linkSunday2.TabStop = true;
            this.linkSunday2.Text = "Sec2";
            this.linkSunday2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkSunday1
            // 
            this.linkSunday1.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkSunday1.AutoSize = true;
            this.linkSunday1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkSunday1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkSunday1.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkSunday1.Location = new System.Drawing.Point(3, 24);
            this.linkSunday1.Name = "linkSunday1";
            this.linkSunday1.Size = new System.Drawing.Size(40, 17);
            this.linkSunday1.TabIndex = 3;
            this.linkSunday1.TabStop = true;
            this.linkSunday1.Text = "Sec1";
            this.linkSunday1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Sunday
            // 
            this.Sunday.AutoSize = true;
            this.Sunday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sunday.Location = new System.Drawing.Point(189, 0);
            this.Sunday.Name = "Sunday";
            this.Sunday.Size = new System.Drawing.Size(71, 24);
            this.Sunday.TabIndex = 0;
            this.Sunday.Text = "Sunday";
            // 
            // Teacher_dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1859, 906);
            this.Controls.Add(this.panel2);
            this.Name = "Teacher_dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teacher_dashboard";
            this.Load += new System.EventHandler(this.Teacher_dashboard_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.Wednesday_panel.ResumeLayout(false);
            this.Wednesday_panel.PerformLayout();
            this.Tuesday_panel.ResumeLayout(false);
            this.Tuesday_panel.PerformLayout();
            this.Monday_panel.ResumeLayout(false);
            this.Monday_panel.PerformLayout();
            this.Sunday_panel.ResumeLayout(false);
            this.Sunday_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label course6;
        private System.Windows.Forms.Label room6;
        private System.Windows.Forms.Label time6;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label course5;
        private System.Windows.Forms.Label room5;
        private System.Windows.Forms.Label time5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label course4;
        private System.Windows.Forms.Label room4;
        private System.Windows.Forms.Label time4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label course3;
        private System.Windows.Forms.Label room3;
        private System.Windows.Forms.Label time3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label course2;
        private System.Windows.Forms.Label room2;
        private System.Windows.Forms.Label time2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label course1;
        private System.Windows.Forms.Label room1;
        private System.Windows.Forms.Label time1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel Wednesday_panel;
        private System.Windows.Forms.LinkLabel linkwednesday5;
        private System.Windows.Forms.Label Wednesday;
        private System.Windows.Forms.LinkLabel linkwednesday4;
        private System.Windows.Forms.LinkLabel linkwednesday3;
        private System.Windows.Forms.LinkLabel linkwednesday1;
        private System.Windows.Forms.LinkLabel linkwednesday2;
        private System.Windows.Forms.Panel Tuesday_panel;
        private System.Windows.Forms.LinkLabel linkTuesday5;
        private System.Windows.Forms.LinkLabel linkTuesday4;
        private System.Windows.Forms.LinkLabel linkTuesday3;
        private System.Windows.Forms.LinkLabel linkTuesday2;
        private System.Windows.Forms.LinkLabel linkTuesday1;
        private System.Windows.Forms.Label Tuesday;
        private System.Windows.Forms.Panel Monday_panel;
        private System.Windows.Forms.LinkLabel linkMonday5;
        private System.Windows.Forms.LinkLabel linkMonday4;
        private System.Windows.Forms.LinkLabel linkMonday3;
        private System.Windows.Forms.LinkLabel linkMonday2;
        private System.Windows.Forms.LinkLabel linkMonday1;
        private System.Windows.Forms.Label Monday;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Sunday_panel;
        private System.Windows.Forms.LinkLabel linkSunday5;
        private System.Windows.Forms.LinkLabel linkSunday4;
        private System.Windows.Forms.LinkLabel linkSunday3;
        private System.Windows.Forms.LinkLabel linkSunday2;
        private System.Windows.Forms.LinkLabel linkSunday1;
        private System.Windows.Forms.Label Sunday;
        private System.Windows.Forms.LinkLabel Profile_link;
        private System.Windows.Forms.Button Back_Button;
    }
}