﻿
namespace University_Management_System
{
    partial class Course_result_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Course_result_comboBox = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.attend2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.quiz4 = new System.Windows.Forms.Label();
            this.quiz3 = new System.Windows.Forms.Label();
            this.final_label = new System.Windows.Forms.Label();
            this.final = new System.Windows.Forms.Label();
            this.final_full = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.attend1 = new System.Windows.Forms.Label();
            this.quiz2 = new System.Windows.Forms.Label();
            this.quiz1 = new System.Windows.Forms.Label();
            this.mid = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.mid_label = new System.Windows.Forms.Label();
            this.mid_full = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.show_just = new System.Windows.Forms.Label();
            this.Teacher_id = new System.Windows.Forms.Label();
            this.teacher_name_label = new System.Windows.Forms.Label();
            this.course_name_sec_label = new System.Windows.Forms.Label();
            this.total_result = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.semester_combo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Grade_link = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Registration_link = new System.Windows.Forms.LinkLabel();
            this.Course_and_result_link = new System.Windows.Forms.LinkLabel();
            this.Back_Button = new System.Windows.Forms.Button();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(7, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(952, 42);
            this.panel4.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(15, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Grades Marks Quizes";
            // 
            // Course_result_comboBox
            // 
            this.Course_result_comboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.Course_result_comboBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Course_result_comboBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.Course_result_comboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Course_result_comboBox.FormattingEnabled = true;
            this.Course_result_comboBox.Location = new System.Drawing.Point(123, 70);
            this.Course_result_comboBox.Name = "Course_result_comboBox";
            this.Course_result_comboBox.Size = new System.Drawing.Size(335, 24);
            this.Course_result_comboBox.TabIndex = 3;
            this.Course_result_comboBox.SelectedIndexChanged += new System.EventHandler(this.Course_result_comboBox_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.semester_combo);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Course_result_comboBox);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Location = new System.Drawing.Point(251, 92);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(979, 702);
            this.panel1.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.attend2);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.quiz4);
            this.panel5.Controls.Add(this.quiz3);
            this.panel5.Controls.Add(this.final_label);
            this.panel5.Controls.Add(this.final);
            this.panel5.Controls.Add(this.final_full);
            this.panel5.Location = new System.Drawing.Point(37, 440);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(893, 189);
            this.panel5.TabIndex = 9;
            // 
            // attend2
            // 
            this.attend2.AutoSize = true;
            this.attend2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attend2.Location = new System.Drawing.Point(670, 154);
            this.attend2.Name = "attend2";
            this.attend2.Size = new System.Drawing.Size(40, 25);
            this.attend2.TabIndex = 13;
            this.attend2.Text = "-(-)";
            this.attend2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(350, 21);
            this.label10.TabIndex = 6;
            this.label10.Text = "Total :100; Passing Mark:50; Contributes:100%";
            this.label10.Visible = false;
            // 
            // quiz4
            // 
            this.quiz4.AutoSize = true;
            this.quiz4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quiz4.Location = new System.Drawing.Point(670, 115);
            this.quiz4.Name = "quiz4";
            this.quiz4.Size = new System.Drawing.Size(40, 25);
            this.quiz4.TabIndex = 12;
            this.quiz4.Text = "-(-)";
            this.quiz4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quiz3
            // 
            this.quiz3.AutoSize = true;
            this.quiz3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quiz3.Location = new System.Drawing.Point(670, 74);
            this.quiz3.Name = "quiz3";
            this.quiz3.Size = new System.Drawing.Size(40, 25);
            this.quiz3.TabIndex = 11;
            this.quiz3.Text = "-(-)";
            this.quiz3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // final_label
            // 
            this.final_label.AutoSize = true;
            this.final_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.final_label.Location = new System.Drawing.Point(13, 60);
            this.final_label.Name = "final_label";
            this.final_label.Size = new System.Drawing.Size(148, 29);
            this.final_label.TabIndex = 4;
            this.final_label.Text = "Finalterm for";
            // 
            // final
            // 
            this.final.AutoSize = true;
            this.final.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.final.Location = new System.Drawing.Point(670, 39);
            this.final.Name = "final";
            this.final.Size = new System.Drawing.Size(40, 25);
            this.final.TabIndex = 10;
            this.final.Text = "-(-)";
            this.final.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // final_full
            // 
            this.final_full.AutoSize = true;
            this.final_full.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.final_full.Location = new System.Drawing.Point(670, 6);
            this.final_full.Name = "final_full";
            this.final_full.Size = new System.Drawing.Size(40, 25);
            this.final_full.TabIndex = 2;
            this.final_full.Text = "-(-)";
            this.final_full.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.attend1);
            this.panel3.Controls.Add(this.quiz2);
            this.panel3.Controls.Add(this.quiz1);
            this.panel3.Controls.Add(this.mid);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.mid_label);
            this.panel3.Controls.Add(this.mid_full);
            this.panel3.Location = new System.Drawing.Point(37, 245);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(893, 189);
            this.panel3.TabIndex = 8;
            // 
            // attend1
            // 
            this.attend1.AutoSize = true;
            this.attend1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attend1.Location = new System.Drawing.Point(670, 153);
            this.attend1.Name = "attend1";
            this.attend1.Size = new System.Drawing.Size(40, 25);
            this.attend1.TabIndex = 9;
            this.attend1.Text = "-(-)";
            this.attend1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quiz2
            // 
            this.quiz2.AutoSize = true;
            this.quiz2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quiz2.Location = new System.Drawing.Point(670, 119);
            this.quiz2.Name = "quiz2";
            this.quiz2.Size = new System.Drawing.Size(40, 25);
            this.quiz2.TabIndex = 8;
            this.quiz2.Text = "-(-)";
            this.quiz2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quiz1
            // 
            this.quiz1.AutoSize = true;
            this.quiz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quiz1.Location = new System.Drawing.Point(670, 78);
            this.quiz1.Name = "quiz1";
            this.quiz1.Size = new System.Drawing.Size(40, 25);
            this.quiz1.TabIndex = 7;
            this.quiz1.Text = "-(-)";
            this.quiz1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mid
            // 
            this.mid.AutoSize = true;
            this.mid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mid.Location = new System.Drawing.Point(670, 43);
            this.mid.Name = "mid";
            this.mid.Size = new System.Drawing.Size(40, 25);
            this.mid.TabIndex = 6;
            this.mid.Text = "-(-)";
            this.mid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(350, 21);
            this.label9.TabIndex = 5;
            this.label9.Text = "Total :100; Passing Mark:50; Contributes:100%";
            this.label9.Visible = false;
            // 
            // mid_label
            // 
            this.mid_label.AutoSize = true;
            this.mid_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mid_label.Location = new System.Drawing.Point(13, 67);
            this.mid_label.Name = "mid_label";
            this.mid_label.Size = new System.Drawing.Size(135, 29);
            this.mid_label.TabIndex = 3;
            this.mid_label.Text = "Midterm for";
            // 
            // mid_full
            // 
            this.mid_full.AutoSize = true;
            this.mid_full.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mid_full.Location = new System.Drawing.Point(670, 7);
            this.mid_full.Name = "mid_full";
            this.mid_full.Size = new System.Drawing.Size(40, 25);
            this.mid_full.TabIndex = 1;
            this.mid_full.Text = "-(-)";
            this.mid_full.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SkyBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.show_just);
            this.panel2.Controls.Add(this.Teacher_id);
            this.panel2.Controls.Add(this.teacher_name_label);
            this.panel2.Controls.Add(this.course_name_sec_label);
            this.panel2.Controls.Add(this.total_result);
            this.panel2.Location = new System.Drawing.Point(8, 115);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(951, 124);
            this.panel2.TabIndex = 7;
            // 
            // show_just
            // 
            this.show_just.AutoSize = true;
            this.show_just.Font = new System.Drawing.Font("Bahnschrift", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_just.Location = new System.Drawing.Point(23, 35);
            this.show_just.Name = "show_just";
            this.show_just.Size = new System.Drawing.Size(393, 21);
            this.show_just.TabIndex = 4;
            this.show_just.Text = "Total Mark :100; Passing Mark:50; Contributes:100%";
            this.show_just.Visible = false;
            // 
            // Teacher_id
            // 
            this.Teacher_id.AutoSize = true;
            this.Teacher_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teacher_id.Location = new System.Drawing.Point(23, 90);
            this.Teacher_id.Name = "Teacher_id";
            this.Teacher_id.Size = new System.Drawing.Size(31, 25);
            this.Teacher_id.TabIndex = 3;
            this.Teacher_id.Text = "ID";
            // 
            // teacher_name_label
            // 
            this.teacher_name_label.AutoSize = true;
            this.teacher_name_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacher_name_label.Location = new System.Drawing.Point(23, 63);
            this.teacher_name_label.Name = "teacher_name_label";
            this.teacher_name_label.Size = new System.Drawing.Size(154, 25);
            this.teacher_name_label.TabIndex = 2;
            this.teacher_name_label.Text = "Course Teacher";
            // 
            // course_name_sec_label
            // 
            this.course_name_sec_label.AutoSize = true;
            this.course_name_sec_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.course_name_sec_label.Location = new System.Drawing.Point(22, 5);
            this.course_name_sec_label.Name = "course_name_sec_label";
            this.course_name_sec_label.Size = new System.Drawing.Size(144, 25);
            this.course_name_sec_label.TabIndex = 1;
            this.course_name_sec_label.Text = "Course Name";
            // 
            // total_result
            // 
            this.total_result.AutoSize = true;
            this.total_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_result.Location = new System.Drawing.Point(842, 81);
            this.total_result.Name = "total_result";
            this.total_result.Size = new System.Drawing.Size(40, 25);
            this.total_result.TabIndex = 0;
            this.total_result.Text = "-(-)";
            this.total_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(583, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Semester:";
            // 
            // semester_combo
            // 
            this.semester_combo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.semester_combo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.semester_combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semester_combo.FormattingEnabled = true;
            this.semester_combo.Location = new System.Drawing.Point(677, 70);
            this.semester_combo.Name = "semester_combo";
            this.semester_combo.Size = new System.Drawing.Size(246, 28);
            this.semester_combo.TabIndex = 5;
            this.semester_combo.SelectedIndexChanged += new System.EventHandler(this.semester_combo_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "Courses: ";
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.Grade_link);
            this.panel6.Controls.Add(this.pictureBox3);
            this.panel6.Controls.Add(this.pictureBox2);
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Controls.Add(this.Registration_link);
            this.panel6.Controls.Add(this.Course_and_result_link);
            this.panel6.Controls.Add(this.Back_Button);
            this.panel6.Location = new System.Drawing.Point(251, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(979, 61);
            this.panel6.TabIndex = 5;
            // 
            // Grade_link
            // 
            this.Grade_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Grade_link.AutoSize = true;
            this.Grade_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grade_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Grade_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Grade_link.Location = new System.Drawing.Point(708, 14);
            this.Grade_link.Name = "Grade_link";
            this.Grade_link.Size = new System.Drawing.Size(66, 25);
            this.Grade_link.TabIndex = 7;
            this.Grade_link.TabStop = true;
            this.Grade_link.Text = "Grade";
            this.Grade_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::University_Management_System.Properties.Resources.grade1;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(651, 10);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(51, 42);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::University_Management_System.Properties.Resources.Registration_pic1;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(469, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 42);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::University_Management_System.Properties.Resources.Course_and_result;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(214, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 42);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Registration_link
            // 
            this.Registration_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Registration_link.AutoSize = true;
            this.Registration_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registration_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Registration_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Registration_link.Location = new System.Drawing.Point(525, 14);
            this.Registration_link.Name = "Registration_link";
            this.Registration_link.Size = new System.Drawing.Size(114, 25);
            this.Registration_link.TabIndex = 2;
            this.Registration_link.TabStop = true;
            this.Registration_link.Text = "Registration";
            this.Registration_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Course_and_result_link
            // 
            this.Course_and_result_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Course_and_result_link.AutoSize = true;
            this.Course_and_result_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Course_and_result_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Course_and_result_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Course_and_result_link.Location = new System.Drawing.Point(268, 14);
            this.Course_and_result_link.Name = "Course_and_result_link";
            this.Course_and_result_link.Size = new System.Drawing.Size(176, 25);
            this.Course_and_result_link.TabIndex = 1;
            this.Course_and_result_link.TabStop = true;
            this.Course_and_result_link.Text = "Course and results";
            this.Course_and_result_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Course_and_result_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Course_and_result_link_LinkClicked);
            // 
            // Back_Button
            // 
            this.Back_Button.BackgroundImage = global::University_Management_System.Properties.Resources.backButton2;
            this.Back_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Back_Button.Location = new System.Drawing.Point(916, -1);
            this.Back_Button.Name = "Back_Button";
            this.Back_Button.Size = new System.Drawing.Size(58, 61);
            this.Back_Button.TabIndex = 0;
            this.Back_Button.UseVisualStyleBackColor = true;
            this.Back_Button.Click += new System.EventHandler(this.Back_Button_Click);
            // 
            // Course_result_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1457, 993);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Name = "Course_result_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Course and Result";
            this.Load += new System.EventHandler(this.Course_result_form_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox Course_result_comboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox semester_combo;
        private System.Windows.Forms.Label final_full;
        private System.Windows.Forms.Label mid_full;
        private System.Windows.Forms.Label total_result;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.LinkLabel Grade_link;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel Registration_link;
        private System.Windows.Forms.LinkLabel Course_and_result_link;
        private System.Windows.Forms.Button Back_Button;
        private System.Windows.Forms.Label teacher_name_label;
        private System.Windows.Forms.Label course_name_sec_label;
        private System.Windows.Forms.Label Teacher_id;
        private System.Windows.Forms.Label show_just;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label final_label;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label mid_label;
        private System.Windows.Forms.Label attend2;
        private System.Windows.Forms.Label quiz4;
        private System.Windows.Forms.Label quiz3;
        private System.Windows.Forms.Label final;
        private System.Windows.Forms.Label attend1;
        private System.Windows.Forms.Label quiz2;
        private System.Windows.Forms.Label quiz1;
        private System.Windows.Forms.Label mid;
    }
}