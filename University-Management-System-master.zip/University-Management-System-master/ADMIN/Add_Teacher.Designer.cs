﻿namespace University_Management_System
{
    partial class Add_Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Adt_Head_Panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bar = new System.Windows.Forms.Panel();
            this.Teacher_Reg_Label = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Adt_Form_Container = new System.Windows.Forms.Panel();
            this.Create_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Position_cmbx = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Department_cmbx = new System.Windows.Forms.ComboBox();
            this.Minimize_btn = new System.Windows.Forms.Button();
            this.FirstName_lb = new System.Windows.Forms.Label();
            this.FirstName_tb = new System.Windows.Forms.TextBox();
            this.LastName_tb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Email_tb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Mobile_tb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.FatherName_tb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.MotherName_tb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.NID_tb = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.House_tb = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Day_tb = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Road_tb = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Area_tb = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.City_tb = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Month_tb = new System.Windows.Forms.TextBox();
            this.Year_tb = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.file = new System.Windows.Forms.OpenFileDialog();
            this.path = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.layout1 = new University_Management_System.Layout();
            this.Adt_Head_Panel.SuspendLayout();
            this.Adt_Form_Container.SuspendLayout();
            this.SuspendLayout();
            // 
            // Adt_Head_Panel
            // 
            this.Adt_Head_Panel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Adt_Head_Panel.Controls.Add(this.panel2);
            this.Adt_Head_Panel.Controls.Add(this.bar);
            this.Adt_Head_Panel.Controls.Add(this.Teacher_Reg_Label);
            this.Adt_Head_Panel.Location = new System.Drawing.Point(280, 109);
            this.Adt_Head_Panel.Name = "Adt_Head_Panel";
            this.Adt_Head_Panel.Size = new System.Drawing.Size(1564, 72);
            this.Adt_Head_Panel.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1564, 10);
            this.panel2.TabIndex = 23;
            // 
            // bar
            // 
            this.bar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bar.Location = new System.Drawing.Point(1440, 0);
            this.bar.Name = "bar";
            this.bar.Size = new System.Drawing.Size(10, 72);
            this.bar.TabIndex = 22;
            // 
            // Teacher_Reg_Label
            // 
            this.Teacher_Reg_Label.AutoSize = true;
            this.Teacher_Reg_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.Teacher_Reg_Label.Location = new System.Drawing.Point(134, 12);
            this.Teacher_Reg_Label.Name = "Teacher_Reg_Label";
            this.Teacher_Reg_Label.Size = new System.Drawing.Size(333, 39);
            this.Teacher_Reg_Label.TabIndex = 0;
            this.Teacher_Reg_Label.Text = "Teacher Registration";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(1740, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 72);
            this.panel1.TabIndex = 23;
            // 
            // Adt_Form_Container
            // 
            this.Adt_Form_Container.BackColor = System.Drawing.Color.White;
            this.Adt_Form_Container.Controls.Add(this.label19);
            this.Adt_Form_Container.Controls.Add(this.label18);
            this.Adt_Form_Container.Controls.Add(this.path);
            this.Adt_Form_Container.Controls.Add(this.label17);
            this.Adt_Form_Container.Controls.Add(this.label16);
            this.Adt_Form_Container.Controls.Add(this.label15);
            this.Adt_Form_Container.Controls.Add(this.Year_tb);
            this.Adt_Form_Container.Controls.Add(this.Month_tb);
            this.Adt_Form_Container.Controls.Add(this.label14);
            this.Adt_Form_Container.Controls.Add(this.City_tb);
            this.Adt_Form_Container.Controls.Add(this.label13);
            this.Adt_Form_Container.Controls.Add(this.Area_tb);
            this.Adt_Form_Container.Controls.Add(this.label12);
            this.Adt_Form_Container.Controls.Add(this.Road_tb);
            this.Adt_Form_Container.Controls.Add(this.label11);
            this.Adt_Form_Container.Controls.Add(this.Day_tb);
            this.Adt_Form_Container.Controls.Add(this.label10);
            this.Adt_Form_Container.Controls.Add(this.House_tb);
            this.Adt_Form_Container.Controls.Add(this.label9);
            this.Adt_Form_Container.Controls.Add(this.NID_tb);
            this.Adt_Form_Container.Controls.Add(this.label8);
            this.Adt_Form_Container.Controls.Add(this.MotherName_tb);
            this.Adt_Form_Container.Controls.Add(this.label7);
            this.Adt_Form_Container.Controls.Add(this.FatherName_tb);
            this.Adt_Form_Container.Controls.Add(this.label6);
            this.Adt_Form_Container.Controls.Add(this.Mobile_tb);
            this.Adt_Form_Container.Controls.Add(this.label5);
            this.Adt_Form_Container.Controls.Add(this.Email_tb);
            this.Adt_Form_Container.Controls.Add(this.label4);
            this.Adt_Form_Container.Controls.Add(this.LastName_tb);
            this.Adt_Form_Container.Controls.Add(this.label3);
            this.Adt_Form_Container.Controls.Add(this.FirstName_tb);
            this.Adt_Form_Container.Controls.Add(this.FirstName_lb);
            this.Adt_Form_Container.Controls.Add(this.Create_btn);
            this.Adt_Form_Container.Controls.Add(this.label2);
            this.Adt_Form_Container.Controls.Add(this.Position_cmbx);
            this.Adt_Form_Container.Controls.Add(this.label1);
            this.Adt_Form_Container.Controls.Add(this.Department_cmbx);
            this.Adt_Form_Container.Location = new System.Drawing.Point(280, 182);
            this.Adt_Form_Container.Margin = new System.Windows.Forms.Padding(0);
            this.Adt_Form_Container.Name = "Adt_Form_Container";
            this.Adt_Form_Container.Size = new System.Drawing.Size(1564, 791);
            this.Adt_Form_Container.TabIndex = 24;
            // 
            // Create_btn
            // 
            this.Create_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Create_btn.Location = new System.Drawing.Point(1039, 500);
            this.Create_btn.Name = "Create_btn";
            this.Create_btn.Size = new System.Drawing.Size(381, 48);
            this.Create_btn.TabIndex = 50;
            this.Create_btn.Text = "Create";
            this.Create_btn.UseVisualStyleBackColor = true;
            this.Create_btn.Click += new System.EventHandler(this.Create_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label2.Location = new System.Drawing.Point(1094, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 36);
            this.label2.TabIndex = 45;
            this.label2.Text = "Position";
            // 
            // Position_cmbx
            // 
            this.Position_cmbx.FormattingEnabled = true;
            this.Position_cmbx.Items.AddRange(new object[] {
            "Lecturer",
            "Professor",
            "Assistant Professor",
            "Department Head",
            "Director",
            "Proctor",
            "Dean",
            "Register"});
            this.Position_cmbx.Location = new System.Drawing.Point(1029, 119);
            this.Position_cmbx.Name = "Position_cmbx";
            this.Position_cmbx.Size = new System.Drawing.Size(236, 24);
            this.Position_cmbx.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.Location = new System.Drawing.Point(761, 385);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 36);
            this.label1.TabIndex = 43;
            this.label1.Text = "Department";
            // 
            // Department_cmbx
            // 
            this.Department_cmbx.FormattingEnabled = true;
            this.Department_cmbx.Items.AddRange(new object[] {
            "ACT",
            "ARCH",
            "BA",
            "BECO",
            "CHEM",
            "COE",
            "CS",
            "EEE",
            "ENG",
            "IPE",
            "LLB",
            "MAT",
            "MKT",
            "PHY"});
            this.Department_cmbx.Location = new System.Drawing.Point(741, 450);
            this.Department_cmbx.Name = "Department_cmbx";
            this.Department_cmbx.Size = new System.Drawing.Size(236, 24);
            this.Department_cmbx.TabIndex = 42;
            // 
            // Minimize_btn
            // 
            this.Minimize_btn.BackColor = System.Drawing.Color.White;
            this.Minimize_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimize_btn.FlatAppearance.BorderSize = 0;
            this.Minimize_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Minimize_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Minimize_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minimize_btn.ForeColor = System.Drawing.Color.White;
            this.Minimize_btn.Image = global::University_Management_System.Properties.Resources.icons8_minus_20;
            this.Minimize_btn.Location = new System.Drawing.Point(1886, 0);
            this.Minimize_btn.Margin = new System.Windows.Forms.Padding(0);
            this.Minimize_btn.Name = "Minimize_btn";
            this.Minimize_btn.Size = new System.Drawing.Size(80, 74);
            this.Minimize_btn.TabIndex = 20;
            this.Minimize_btn.UseVisualStyleBackColor = false;
            this.Minimize_btn.Click += new System.EventHandler(this.Minimize_btn_Click);
            // 
            // FirstName_lb
            // 
            this.FirstName_lb.AutoSize = true;
            this.FirstName_lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.FirstName_lb.Location = new System.Drawing.Point(147, 62);
            this.FirstName_lb.Name = "FirstName_lb";
            this.FirstName_lb.Size = new System.Drawing.Size(137, 29);
            this.FirstName_lb.TabIndex = 51;
            this.FirstName_lb.Text = "First Name";
            // 
            // FirstName_tb
            // 
            this.FirstName_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.FirstName_tb.Location = new System.Drawing.Point(124, 114);
            this.FirstName_tb.Name = "FirstName_tb";
            this.FirstName_tb.Size = new System.Drawing.Size(241, 31);
            this.FirstName_tb.TabIndex = 52;
            // 
            // LastName_tb
            // 
            this.LastName_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.LastName_tb.Location = new System.Drawing.Point(425, 114);
            this.LastName_tb.Name = "LastName_tb";
            this.LastName_tb.Size = new System.Drawing.Size(241, 31);
            this.LastName_tb.TabIndex = 54;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label3.Location = new System.Drawing.Point(448, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 29);
            this.label3.TabIndex = 53;
            this.label3.Text = "Last Name";
            // 
            // Email_tb
            // 
            this.Email_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Email_tb.Location = new System.Drawing.Point(728, 114);
            this.Email_tb.Name = "Email_tb";
            this.Email_tb.Size = new System.Drawing.Size(241, 31);
            this.Email_tb.TabIndex = 56;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label4.Location = new System.Drawing.Point(751, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 29);
            this.label4.TabIndex = 55;
            this.label4.Text = "Email";
            // 
            // Mobile_tb
            // 
            this.Mobile_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Mobile_tb.Location = new System.Drawing.Point(124, 272);
            this.Mobile_tb.Name = "Mobile_tb";
            this.Mobile_tb.Size = new System.Drawing.Size(241, 31);
            this.Mobile_tb.TabIndex = 58;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label5.Location = new System.Drawing.Point(147, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 29);
            this.label5.TabIndex = 57;
            this.label5.Text = "Mobile";
            // 
            // FatherName_tb
            // 
            this.FatherName_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.FatherName_tb.Location = new System.Drawing.Point(425, 272);
            this.FatherName_tb.Name = "FatherName_tb";
            this.FatherName_tb.Size = new System.Drawing.Size(241, 31);
            this.FatherName_tb.TabIndex = 60;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label6.Location = new System.Drawing.Point(448, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 29);
            this.label6.TabIndex = 59;
            this.label6.Text = "Father Name";
            // 
            // MotherName_tb
            // 
            this.MotherName_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.MotherName_tb.Location = new System.Drawing.Point(739, 272);
            this.MotherName_tb.Name = "MotherName_tb";
            this.MotherName_tb.Size = new System.Drawing.Size(241, 31);
            this.MotherName_tb.TabIndex = 62;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label7.Location = new System.Drawing.Point(762, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 29);
            this.label7.TabIndex = 61;
            this.label7.Text = "Mother Name";
            // 
            // NID_tb
            // 
            this.NID_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.NID_tb.Location = new System.Drawing.Point(124, 442);
            this.NID_tb.Name = "NID_tb";
            this.NID_tb.Size = new System.Drawing.Size(241, 31);
            this.NID_tb.TabIndex = 64;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label8.Location = new System.Drawing.Point(147, 390);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 29);
            this.label8.TabIndex = 63;
            this.label8.Text = "NID";
            // 
            // House_tb
            // 
            this.House_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.House_tb.Location = new System.Drawing.Point(126, 609);
            this.House_tb.Name = "House_tb";
            this.House_tb.Size = new System.Drawing.Size(162, 31);
            this.House_tb.TabIndex = 66;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label9.Location = new System.Drawing.Point(149, 557);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 29);
            this.label9.TabIndex = 65;
            this.label9.Text = "House";
            // 
            // Day_tb
            // 
            this.Day_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Day_tb.Location = new System.Drawing.Point(425, 451);
            this.Day_tb.Name = "Day_tb";
            this.Day_tb.Size = new System.Drawing.Size(68, 31);
            this.Day_tb.TabIndex = 68;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label10.Location = new System.Drawing.Point(455, 381);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 29);
            this.label10.TabIndex = 67;
            this.label10.Text = "Date of Birth";
            // 
            // Road_tb
            // 
            this.Road_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Road_tb.Location = new System.Drawing.Point(331, 609);
            this.Road_tb.Name = "Road_tb";
            this.Road_tb.Size = new System.Drawing.Size(162, 31);
            this.Road_tb.TabIndex = 70;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label11.Location = new System.Drawing.Point(354, 557);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 29);
            this.label11.TabIndex = 69;
            this.label11.Text = "Road";
            // 
            // Area_tb
            // 
            this.Area_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Area_tb.Location = new System.Drawing.Point(540, 609);
            this.Area_tb.Name = "Area_tb";
            this.Area_tb.Size = new System.Drawing.Size(162, 31);
            this.Area_tb.TabIndex = 72;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label12.Location = new System.Drawing.Point(563, 557);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 29);
            this.label12.TabIndex = 71;
            this.label12.Text = "Area";
            // 
            // City_tb
            // 
            this.City_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.City_tb.Location = new System.Drawing.Point(739, 609);
            this.City_tb.Name = "City_tb";
            this.City_tb.Size = new System.Drawing.Size(162, 31);
            this.City_tb.TabIndex = 74;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label13.Location = new System.Drawing.Point(762, 557);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 29);
            this.label13.TabIndex = 73;
            this.label13.Text = "City";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label14.Location = new System.Drawing.Point(121, 508);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 29);
            this.label14.TabIndex = 75;
            this.label14.Text = "Address";
            // 
            // Month_tb
            // 
            this.Month_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Month_tb.Location = new System.Drawing.Point(516, 451);
            this.Month_tb.Name = "Month_tb";
            this.Month_tb.Size = new System.Drawing.Size(68, 31);
            this.Month_tb.TabIndex = 76;
            // 
            // Year_tb
            // 
            this.Year_tb.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.Year_tb.Location = new System.Drawing.Point(598, 451);
            this.Year_tb.Name = "Year_tb";
            this.Year_tb.Size = new System.Drawing.Size(89, 31);
            this.Year_tb.TabIndex = 77;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.label15.Location = new System.Drawing.Point(445, 423);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 15);
            this.label15.TabIndex = 78;
            this.label15.Text = "Day";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.label16.Location = new System.Drawing.Point(531, 425);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 15);
            this.label16.TabIndex = 79;
            this.label16.Text = "Month";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.label17.Location = new System.Drawing.Point(626, 423);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 15);
            this.label17.TabIndex = 80;
            this.label17.Text = "Year";
            // 
            // file
            // 
            this.file.FileName = "Profile Image";
            // 
            // path
            // 
            this.path.Font = new System.Drawing.Font("Dubai", 8.25F);
            this.path.Location = new System.Drawing.Point(1029, 272);
            this.path.Name = "path";
            this.path.Size = new System.Drawing.Size(311, 31);
            this.path.TabIndex = 81;
            this.path.Click += new System.EventHandler(this.path_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label18.Location = new System.Drawing.Point(1094, 196);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(158, 36);
            this.label18.TabIndex = 82;
            this.label18.Text = "Add Image";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.label19.Location = new System.Drawing.Point(1036, 245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 15);
            this.label19.TabIndex = 83;
            this.label19.Text = "Insert your file path";
            // 
            // layout1
            // 
            this.layout1.Location = new System.Drawing.Point(0, 0);
            this.layout1.Margin = new System.Windows.Forms.Padding(0);
            this.layout1.Name = "layout1";
            this.layout1.Size = new System.Drawing.Size(2049, 1065);
            this.layout1.TabIndex = 2;
            // 
            // Add_Teacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2049, 1065);
            this.Controls.Add(this.Adt_Form_Container);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Minimize_btn);
            this.Controls.Add(this.Adt_Head_Panel);
            this.Controls.Add(this.layout1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Teacher";
            this.Text = "Add_Teacher";
            this.Adt_Head_Panel.ResumeLayout(false);
            this.Adt_Head_Panel.PerformLayout();
            this.Adt_Form_Container.ResumeLayout(false);
            this.Adt_Form_Container.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Adt_Head_Panel;
        private Layout layout1;
        private System.Windows.Forms.Button Minimize_btn;
        private System.Windows.Forms.Panel bar;
        private System.Windows.Forms.Label Teacher_Reg_Label;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Adt_Form_Container;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Department_cmbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Position_cmbx;
        private System.Windows.Forms.Button Create_btn;
        private System.Windows.Forms.TextBox FirstName_tb;
        private System.Windows.Forms.Label FirstName_lb;
        private System.Windows.Forms.TextBox Day_tb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox House_tb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox NID_tb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox MotherName_tb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox FatherName_tb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Mobile_tb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Email_tb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LastName_tb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox City_tb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Area_tb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Road_tb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Year_tb;
        private System.Windows.Forms.TextBox Month_tb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.OpenFileDialog file;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox path;
        private System.Windows.Forms.Label label19;
    }
}