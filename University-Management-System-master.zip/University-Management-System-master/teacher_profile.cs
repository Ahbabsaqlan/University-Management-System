﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace University_Management_System
{
    internal partial class teacher_profile : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        Teacher teacher2;
        public teacher_profile(Teacher teachers)
        {
            teacher2 = teachers;
            InitializeComponent();
        }

        private void teacher_profile_Load(object sender, EventArgs e)
        {
            full_name_lbl.Text = teacher2.FirstName + " " + teacher2.LastName;
            label1.Text = "Student ID :  " + teacher2.ID;
           // label2.Text = "CGPA :  " + student.CGPA;
            //label3.Text = "Credit :  " + student.CreditComplete;
            label4.Text = "Email :  " + teacher2.Email;
            label5.Text = "NID :  " + teacher2.NID;
            label6.Text = "Father Name :  " + teacher2.FatherName;
            label7.Text = "Mother Name : " + teacher2.MotherName;
            label8.Text = "Mobile :  " + teacher2.Mobile;
            label9.Text = "Date of Birth :  " + teacher2.DOB.Day + "-" + teacher2.DOB.Month + "-" + teacher2.DOB.Year;
          //  program.Text = "Program :  " + teacher2.;
            City.Text = "City : " + teacher2.Address.City;
            Area.Text = "Area : " + teacher2.Address.Area;
            House.Text = "House : " + teacher2.Address.House;
            Road.Text = "Road : " + teacher2.Address.Road;

            Person_photo.Image = Image.FromStream(teacher2.Images);
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query1 = "update LOGIN set password='" + pass_change_box.Text + "' where user_id= '" + teacher2.ID + "'";

            SqlCommand cmd = new SqlCommand(query1, connection);
            connection.Open();
            if (connection.State == ConnectionState.Open)
            {
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("Update Successful!");
                }
                connection.Close();
            }

            string query2 = "update TEACHER set Password='" + pass_change_box.Text + "' where Teacher_ID= '" + teacher2.ID + "'";

            SqlCommand cmd2 = new SqlCommand(query2, connection);
            connection.Open();
            if (connection.State == ConnectionState.Open)
            {
                int result1 = cmd2.ExecuteNonQuery();
                if (result1 > 0)
                {
                    MessageBox.Show("Update Successful!");
                }
                connection.Close();
            }
        }

        private void Back_Button_Click(object sender, EventArgs e)
        {
            Teacher_dashboard ttt = new Teacher_dashboard(teacher2);
            this.Hide();
            ttt.Show();
        }
    }
}
