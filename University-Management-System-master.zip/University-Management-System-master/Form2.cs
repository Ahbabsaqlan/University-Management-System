﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace University_Management_System
{
    internal partial class Student_dashboard : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        // SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=UNIVERSITY_MANAGEMENT_SYSTEM;Integrated Security=True");



        public static Student student;
        public Student_dashboard(Student students)
        {
            //this.login_id = n;
            InitializeComponent();
            student = students;
        }
        Section[] sunday = new Section[5];
        Section[] monday = new Section[5];
        private void Student_dashboard_Load(object sender, EventArgs e)
        {

            student.getCoursesInfo();
            int count1 = 0;int count2= 0;
            
            string[] sunday_tuesday=new string[] {"","","","",""};
            string[] monday_thursday= new string[] { "", "", "", "", "" };
            for(int i=0;i<student.RegisteredCourses.Length; i++)
            {
                sunday_tuesday[i] = "";
                monday_thursday[i] = "";
                if (student.RegisteredCourses[i].Schedules.ScheduleDay == "sunday-tuesday")
                {
                    sunday[count1] = new Section(student.RegisteredCourses[i].ID);
                    sunday_tuesday[count1]= student.RegisteredCourses[i].Courses.CourseName + " [" + student.RegisteredCourses[i].SectionName + "] " + student.RegisteredCourses[i].RoomNo;
                    count1++;
                }
                else if(student.RegisteredCourses[i].Schedules.ScheduleDay == "monday-wednesday")
                {
                    monday[count2]= new Section(student.RegisteredCourses[i].ID);
                    monday_thursday[count2]= student.RegisteredCourses[i].Courses.CourseName + " [" + student.RegisteredCourses[i].SectionName + "] " + student.RegisteredCourses[i].RoomNo;
                    count2++;
                }
            }

            linkSunday1.Text= linkTuesday1.Text = sunday_tuesday[0];
            linkSunday2.Text= linkTuesday2.Text = sunday_tuesday[1];
            linkSunday3.Text = linkTuesday3.Text= sunday_tuesday[2];
            linkSunday4.Text = linkTuesday4.Text= sunday_tuesday[3];
            linkSunday5.Text = linkTuesday5.Text= sunday_tuesday[4];
            
            linkMonday1.Text = linkwednesday1.Text = monday_thursday[0];
            linkMonday2.Text = linkwednesday2.Text = monday_thursday[1];
            linkMonday3.Text = linkwednesday3.Text = monday_thursday[2];
            linkMonday4.Text = linkwednesday4.Text = monday_thursday[3];
            linkMonday5.Text = linkwednesday5.Text = monday_thursday[4];

            
            Profile_link.Text = student.FirstName;

            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();

            // int cnt = 0;
            for (int i=0; i<student.RegisteredCourses.Length; i++)
            {
                if (!comboBox1.Items.Contains(student.RegisteredCourses[i].Semester))
                {
                    comboBox1.Items.Add(student.RegisteredCourses[i].Semester);
                }
                if ( i==0)
                {
                    course1.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room1.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time1.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                    panel5.Show();
                }
                else if (i == 1)
                {
                    panel6.Show();
                    course2.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room2.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time2.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 2)
                {
                    panel7.Show();
                    course3.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room3.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time3.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 3)
                {
                    panel8.Show();
                    course4.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room4.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time4.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 4)
                {
                    panel9.Show();
                    course5.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room5.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time5.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 5)
                {
                    panel10.Show();
                    course6.Text = student.RegisteredCourses[i].Courses.CourseName;
                    room6.Text = "Room:-  " + student.RegisteredCourses[i].RoomNo;
                    time6.Text = "Time:-  " + student.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                
            }

        }

        private void Profile_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ProfileShow pfs = new ProfileShow(student);
            this.Hide();
            pfs.Show();

        }

        private void Back_Button_Click(object sender, EventArgs e)
        {
            Login1 log = new Login1();
            this.Hide();
            log.Show();
        }

        private void linkSunday1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Tsf tsf = new Tsf(student, sunday[0]);
           
            LinkLabel link = (LinkLabel)sender;
            // string ss = link.Text;

            //string sss = ss.Substring(0, ss.IndexOf("]")+1);

            if (linkSunday1 == link || linkTuesday1 == link)
            {
                Tsf tsf = new Tsf(student, sunday[0]);
                
                this.Hide();
                tsf.Show();
            }
            else if (linkSunday2 == link || linkTuesday2 == link)
            {
                Tsf tsf = new Tsf(student, sunday[1]);
                this.Hide();
                tsf.Show();
            }
            else if (linkSunday3 == link || linkTuesday3 == link)
            {
                Tsf tsf = new Tsf(student, sunday[2]);
                this.Hide();
                tsf.Show();
            }
            else if (linkSunday4 == link || linkTuesday4 == link)
            {
                Tsf tsf = new Tsf(student, sunday[3]);
                this.Hide();
                tsf.Show();
            }
            else if (linkSunday5 == link || linkTuesday5 == link)
            {
                Tsf tsf = new Tsf(student, sunday[4]);
                this.Hide();
                tsf.Show();
            }
           
        }

        private void linkMonday1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LinkLabel link1 = (LinkLabel)sender;

            if (linkMonday1 == link1 || linkwednesday1 == link1)
            {
                Tsf tsf = new Tsf(student, monday[0]);
                this.Hide();
                tsf.Show();
            }
            else if (linkMonday2 == link1 || linkwednesday2 == link1)
            {
                Tsf tsf = new Tsf(student, monday[1]);
                this.Hide();
                tsf.Show();
            }
            else if (linkMonday3 == link1 || linkwednesday3 == link1)
            {
                Tsf tsf = new Tsf(student, monday[2]);
                this.Hide();
                tsf.Show();
            }
            else if (linkMonday4 == link1 || linkwednesday4 == link1)
            {
                Tsf tsf = new Tsf(student, monday[3]);
                this.Hide();
                tsf.Show();
            }
            else if (linkMonday5 == link1 || linkwednesday5 == link1)
            {
                Tsf tsf = new Tsf(student, monday[4]);
                this.Hide();
                tsf.Show();
            }

        }

        private void Course_and_result_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Course_result_form result=new  Course_result_form(student);
            this.Hide();
            result.Show();
        }

        //private void linkSunday2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    Tsf tsf = new Tsf(student, sunday[1]);
        //    this.Hide();
        //    tsf.Show();
        //}

        //private void linkSunday3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    Tsf tsf = new Tsf(student, sunday[2]);
        //    this.Hide();
        //    tsf.Show();
        //}

        //private void linkSunday4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    Tsf tsf = new Tsf(student, sunday[3]);
        //    this.Hide();
        //    tsf.Show();
        //}

        //private void linkSunday5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    Tsf tsf = new Tsf(student, sunday[1]);
        //    this.Hide();
        //    tsf.Show();
        //}
    }
}
