﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace University_Management_System
{
    internal partial class Course_result_form : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        // SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        Student std;
        //Section sect;
        public Course_result_form(Student students)
        {
            std = students;
           // sect = sections;
            InitializeComponent();
            //Student st = new Student(Student_dashboard.student.ID);
        }
       // int n=std.RegisteredCourses.

        
        private void Course_result_form_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < std.RegisteredCourses.Length; i++)
            {
                if (!semester_combo.Items.Contains(std.RegisteredCourses[i].Semester))
                {
                    semester_combo.Items.Add(std.RegisteredCourses[i].Semester);
                }
           
            }
              
        }

        private void semester_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] hold = new string[std.RegisteredCourses.Length];
            for (int i = 0; i < std.RegisteredCourses.Length; i++)
            {
                if (semester_combo.SelectedItem.ToString() == std.RegisteredCourses[i].Semester)
                {
                    hold[i] = std.RegisteredCourses[i].Courses.CourseName + " [" + std.RegisteredCourses[i].SectionName + "] ";
                    Course_result_comboBox.Items.Add(hold[i]);
                }
            }
        }
        private void Course_result_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Course_result_comboBox.SelectedItem.
            int combo_index = Course_result_comboBox.SelectedIndex;

            show_just.Visible = true;
            teacher_name_label.Text = "Course Teacher: " + std.RegisteredCourses[combo_index].Teachers.FirstName + " " + std.RegisteredCourses[combo_index].Teachers.LastName;
            Teacher_id.Text = std.RegisteredCourses[combo_index].Teachers.ID;
            mid_label.Text = "Midterm for" + std.RegisteredCourses[combo_index].Semester;
            final_label.Text = "Finalterm for" + std.RegisteredCourses[combo_index].Semester;
            //final_full.Text=

            for(int i=0; i< std.RegisteredCourses[combo_index].RegisteredStudents.Students.Length; i++)
            {
                if(std.RegisteredCourses[combo_index].RegisteredStudents.Students[i].ID == std.ID)
                {
                    mid.Text = "Mid Term: " + (std.RegisteredCourses[combo_index].Results[i].MidExam).ToString();
                    quiz1.Text = "Quiz-1: " + (std.RegisteredCourses[combo_index].Results[i].Quiz1).ToString();
                    quiz2.Text = "Quiz-2: " + (std.RegisteredCourses[combo_index].Results[i].Quiz2).ToString();
                    attend1.Text = "Attendence: " + (std.RegisteredCourses[combo_index].Results[i].AttendanceMid).ToString();
                    mid_full.Text = "Mid: " + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString();
                    
                    
                    final.Text = "Final Term: " + (std.RegisteredCourses[combo_index].Results[i].FinalExam).ToString();
                    quiz3.Text = "Quiz-1: " + (std.RegisteredCourses[combo_index].Results[i].Quiz3).ToString();
                    quiz4.Text = "Quiz-2: " + (std.RegisteredCourses[combo_index].Results[i].Quiz4).ToString();
                    attend2.Text = "Attendence: " + (std.RegisteredCourses[combo_index].Results[i].AttendanceFinal).ToString();
                    final_full.Text= "Final: " + (std.RegisteredCourses[combo_index].Results[i].FinalResult).ToString();
                   // total_result.Text = (std.RegisteredCourses[combo_index].Results[i].Grade).ToString();

                    if (90<= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " A+ (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString()+")";
                    }
                    else if (85 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " A (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString() + ")";
                    }
                    else if (80 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " B+ (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString() + ")";
                    }
                    else if (75 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " B (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString() + ")";
                    }
                    else if (70 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " C+ (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString() + ")";
                    }
                    else if (65 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " C (" + (std.RegisteredCourses[combo_index].Results[i].MidResult).ToString() + ")";
                    }
                    else if (60 <= (std.RegisteredCourses[combo_index].Results[i].Grade))
                    {
                        total_result.Text = " D+ (" + (std.RegisteredCourses[combo_index].Results[i].Grade).ToString() + ")";
                    }
                    
                }
            }
        }

        private void Back_Button_Click(object sender, EventArgs e)
        {
            Student_dashboard sd = new Student_dashboard(std);
            this.Hide();
            sd.Show();
        }

        private void Course_and_result_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("YOU ALREADY IN THIS PAGE");
        }

        
    }
}
