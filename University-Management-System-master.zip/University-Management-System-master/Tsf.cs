﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace University_Management_System
{
    internal partial class Tsf : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        // SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        Student student;
        Section sec;
        Teacher teach;
        public Tsf(Student students, Section sections)
        {
            student = students;
            sec = sections;
            
            teach = sec.Teachers;
            InitializeComponent();
            
        }

        private void Minimize_Click(object sender, EventArgs e)
        {
           // WindowState = FormWindowState.Minimized;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
           // Application.Exit();
        }

        private void Course_and_result_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Course_result_form result = new Course_result_form(student);
            this.Hide();
            result.Show();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Grade_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
        Label labels;
        private void Tsf_Load(object sender, EventArgs e)
        {
            Profile_link.Text = student.FirstName;


            courseName.Text = sec.Courses.CourseName + " ["+sec.SectionName+"] ";
            Teacher_name.Text = sec.Teachers.FirstName +" "+ sec.Teachers.LastName;
            Teacher_email.Text = sec.Teachers.Email;
            DAY.Text = sec.Schedules.ScheduleDay;
            Class_time.Text = sec.Schedules.ScheduleTime;
            Room_no.Text = sec.RoomNo;


            Teacher_pic_box.Image = Image.FromStream(sec.Teachers.Images);

            //notice
            labels = new Label();
            labels.Font = new Font("calibiri", 15);
            labels.AutoSize = true;
            labels.ForeColor = Color.DeepSkyBlue;
            labels.Location = new Point(30, 30);
            labels.MouseClick += labels_Click;

           
            for (int i=0; i<sec.Notices.NoticesContent.Length; i++)
            {
                labels.Text = sec.Notices.NoticesContent[i].Title;
                //tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.AutoSize) );
                tableLayoutPanel2.Controls.Add(labels,0,i);
            }
            


            //TSF color
            teach.getRegisteredCourses(teach.ID);
            for(int i=0; i<teach.RegisteredCourses.Length; i++)
            {
                if (teach.RegisteredCourses[i].Schedules.ScheduleDay == "sunday-tuesday")
                {
                    if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "8.00-9.30")
                    {
                        tsf1.BackColor = Color.Yellow;
                        panel37.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "9.30-11.00")
                    {
                        panel2.BackColor = Color.Yellow;
                        panel28.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "11.00-12.30")
                    {
                        panel4.BackColor = Color.Yellow;
                        panel32.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "12.30-2.00")
                    {
                        panel33.BackColor = Color.Yellow;
                        panel30.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "2.00-3.30")
                    {
                        panel41.BackColor = Color.Yellow;
                        panel39.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "3.30-5.00")
                    {
                        panel44.BackColor = Color.Yellow;
                        panel43.BackColor = Color.Yellow;
                    }
                }
                else if(teach.RegisteredCourses[i].Schedules.ScheduleDay == "monday-wednesday")
                {
                    if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "8.00-9.30")
                    {
                        panel5.BackColor = Color.Yellow;
                        panel18.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "9.30-11.00")
                    {
                        panel21.BackColor = Color.Yellow;
                        panel42.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "11.00-12.30")
                    {
                        panel23.BackColor = Color.Yellow;
                        panel34.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "12.30-2.00")
                    {
                        panel29.BackColor = Color.Yellow;
                        panel22.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "2.00-3.30")
                    {
                        panel38.BackColor = Color.Yellow;
                        panel31.BackColor = Color.Yellow;
                    }
                    else if (teach.RegisteredCourses[i].Schedules.ScheduleTime == "3.30-5.00")
                    {
                        panel40.BackColor = Color.Yellow;
                        panel19.BackColor = Color.Yellow;
                    }
                }
            }

        }
        private void labels_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < sec.Notices.NoticesContent.Length; i++)
            {
                if (sec.Notices.NoticesContent[i].Title == labels.Text)
                    MessageBox.Show(sec.Notices.NoticesContent[i].Noticed);

            }
        }
        private void Back_Button_Click(object sender, EventArgs e)
        {
            Student_dashboard st = new Student_dashboard(student);
            this.Hide();
            st.Show();
        }

        private void Profile_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ProfileShow pshow = new ProfileShow(student);
            this.Hide();
            pshow.Show();
        }

        private void tsf1_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}
