﻿namespace University_Management_System
{
    partial class Tsf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Back_Button = new System.Windows.Forms.Button();
            this.Profile_link = new System.Windows.Forms.LinkLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Grade_link = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Registration_link = new System.Windows.Forms.LinkLabel();
            this.Course_and_result_link = new System.Windows.Forms.LinkLabel();
            this.teacher_info = new System.Windows.Forms.Panel();
            this.notice = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.linkLabel16 = new System.Windows.Forms.LinkLabel();
            this.linkLabel17 = new System.Windows.Forms.LinkLabel();
            this.linkLabel18 = new System.Windows.Forms.LinkLabel();
            this.linkLabel19 = new System.Windows.Forms.LinkLabel();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tsf1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.time = new System.Windows.Forms.TableLayoutPanel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.Class_time = new System.Windows.Forms.LinkLabel();
            this.Room_no = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.DAY = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.Teacher_email = new System.Windows.Forms.LinkLabel();
            this.Teacher_name = new System.Windows.Forms.LinkLabel();
            this.Teacher_pic_box = new System.Windows.Forms.PictureBox();
            this.courseName = new System.Windows.Forms.LinkLabel();
            this.Minimize = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.teacher_info.SuspendLayout();
            this.notice.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.time.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Teacher_pic_box)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Back_Button);
            this.panel1.Controls.Add(this.Profile_link);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Grade_link);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.Registration_link);
            this.panel1.Controls.Add(this.Course_and_result_link);
            this.panel1.Location = new System.Drawing.Point(172, 21);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(4);
            this.panel1.Size = new System.Drawing.Size(1142, 71);
            this.panel1.TabIndex = 1;
            // 
            // Back_Button
            // 
            this.Back_Button.BackgroundImage = global::University_Management_System.Properties.Resources.backButton2;
            this.Back_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Back_Button.Location = new System.Drawing.Point(1074, 6);
            this.Back_Button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Back_Button.Name = "Back_Button";
            this.Back_Button.Size = new System.Drawing.Size(59, 62);
            this.Back_Button.TabIndex = 14;
            this.Back_Button.UseVisualStyleBackColor = true;
            this.Back_Button.Click += new System.EventHandler(this.Back_Button_Click);
            // 
            // Profile_link
            // 
            this.Profile_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Profile_link.AutoSize = true;
            this.Profile_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Profile_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Profile_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Profile_link.Location = new System.Drawing.Point(797, 22);
            this.Profile_link.Name = "Profile_link";
            this.Profile_link.Size = new System.Drawing.Size(66, 25);
            this.Profile_link.TabIndex = 13;
            this.Profile_link.TabStop = true;
            this.Profile_link.Text = "Profile";
            this.Profile_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Profile_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Profile_link_LinkClicked);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::University_Management_System.Properties.Resources.profile1;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(734, 18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(57, 38);
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::University_Management_System.Properties.Resources.Course_and_result;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(103, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 42);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // Grade_link
            // 
            this.Grade_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Grade_link.AutoSize = true;
            this.Grade_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Grade_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Grade_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Grade_link.Location = new System.Drawing.Point(642, 23);
            this.Grade_link.Name = "Grade_link";
            this.Grade_link.Size = new System.Drawing.Size(66, 25);
            this.Grade_link.TabIndex = 7;
            this.Grade_link.TabStop = true;
            this.Grade_link.Text = "Grade";
            this.Grade_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Grade_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Grade_link_LinkClicked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.ErrorImage = global::University_Management_System.Properties.Resources.icons8_user_menu_male_64_1;
            this.pictureBox3.Image = global::University_Management_System.Properties.Resources.icons8_thumbnails_50_1;
            this.pictureBox3.Location = new System.Drawing.Point(583, 14);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(53, 49);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.WaitOnLoad = true;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Image = global::University_Management_System.Properties.Resources.icons8_form_50_1;
            this.pictureBox2.Location = new System.Drawing.Point(370, 14);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 49);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Registration_link
            // 
            this.Registration_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Registration_link.AutoSize = true;
            this.Registration_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registration_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Registration_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Registration_link.Location = new System.Drawing.Point(429, 23);
            this.Registration_link.Name = "Registration_link";
            this.Registration_link.Size = new System.Drawing.Size(114, 25);
            this.Registration_link.TabIndex = 2;
            this.Registration_link.TabStop = true;
            this.Registration_link.Text = "Registration";
            this.Registration_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Course_and_result_link
            // 
            this.Course_and_result_link.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Course_and_result_link.AutoSize = true;
            this.Course_and_result_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Course_and_result_link.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Course_and_result_link.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.Course_and_result_link.Location = new System.Drawing.Point(157, 23);
            this.Course_and_result_link.Name = "Course_and_result_link";
            this.Course_and_result_link.Size = new System.Drawing.Size(176, 25);
            this.Course_and_result_link.TabIndex = 1;
            this.Course_and_result_link.TabStop = true;
            this.Course_and_result_link.Text = "Course and results";
            this.Course_and_result_link.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Course_and_result_link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Course_and_result_link_LinkClicked);
            // 
            // teacher_info
            // 
            this.teacher_info.AllowDrop = true;
            this.teacher_info.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.teacher_info.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.teacher_info.Controls.Add(this.notice);
            this.teacher_info.Controls.Add(this.time);
            this.teacher_info.Controls.Add(this.linkLabel3);
            this.teacher_info.Controls.Add(this.Teacher_email);
            this.teacher_info.Controls.Add(this.Teacher_name);
            this.teacher_info.Controls.Add(this.Teacher_pic_box);
            this.teacher_info.Controls.Add(this.courseName);
            this.teacher_info.Location = new System.Drawing.Point(173, 96);
            this.teacher_info.Margin = new System.Windows.Forms.Padding(4);
            this.teacher_info.Name = "teacher_info";
            this.teacher_info.Size = new System.Drawing.Size(1141, 848);
            this.teacher_info.TabIndex = 10;
            this.teacher_info.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // notice
            // 
            this.notice.AllowDrop = true;
            this.notice.Controls.Add(this.tabPage1);
            this.notice.Controls.Add(this.tabPage2);
            this.notice.Controls.Add(this.tabPage3);
            this.notice.HotTrack = true;
            this.notice.ItemSize = new System.Drawing.Size(60, 30);
            this.notice.Location = new System.Drawing.Point(4, 297);
            this.notice.Margin = new System.Windows.Forms.Padding(4);
            this.notice.Name = "notice";
            this.notice.SelectedIndex = 0;
            this.notice.Size = new System.Drawing.Size(1129, 544);
            this.notice.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1121, 506);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tsf";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.8777F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.1223F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 143F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 141F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 157F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel42, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel43, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel44, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel40, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel41, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel38, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel39, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel35, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel37, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel28, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel29, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel30, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel31, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel32, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel33, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel34, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel20, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel22, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel26, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel11, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel12, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel14, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel14, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel15, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel16, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel17, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel18, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel19, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.linkLabel20, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tsf1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel27, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel25, 5, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 7);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.491741F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.58471F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1105, 487);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.SteelBlue;
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel42.Location = new System.Drawing.Point(520, 111);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(132, 68);
            this.panel42.TabIndex = 25;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.SteelBlue;
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel43.Location = new System.Drawing.Point(376, 411);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(137, 68);
            this.panel43.TabIndex = 25;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.SteelBlue;
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel44.Location = new System.Drawing.Point(133, 411);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(108, 68);
            this.panel44.TabIndex = 25;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.SteelBlue;
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel40.Location = new System.Drawing.Point(248, 411);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(121, 68);
            this.panel40.TabIndex = 25;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.SteelBlue;
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel41.Location = new System.Drawing.Point(133, 336);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(108, 68);
            this.panel41.TabIndex = 25;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.SteelBlue;
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel38.Location = new System.Drawing.Point(248, 336);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(121, 68);
            this.panel38.TabIndex = 25;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.SteelBlue;
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel39.Location = new System.Drawing.Point(376, 336);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(137, 68);
            this.panel39.TabIndex = 25;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.SteelBlue;
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.panel36);
            this.panel35.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel35.Location = new System.Drawing.Point(659, 411);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(141, 68);
            this.panel35.TabIndex = 25;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.SteelBlue;
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel36.Location = new System.Drawing.Point(47, 60);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(115, 68);
            this.panel36.TabIndex = 25;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.SteelBlue;
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel37.Location = new System.Drawing.Point(376, 36);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(137, 68);
            this.panel37.TabIndex = 25;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.SteelBlue;
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel28.Location = new System.Drawing.Point(376, 111);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(137, 68);
            this.panel28.TabIndex = 25;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.SteelBlue;
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel29.Location = new System.Drawing.Point(248, 261);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(121, 68);
            this.panel29.TabIndex = 25;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.SteelBlue;
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel30.Location = new System.Drawing.Point(376, 261);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(137, 68);
            this.panel30.TabIndex = 25;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.SteelBlue;
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel31.Location = new System.Drawing.Point(520, 336);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(132, 68);
            this.panel31.TabIndex = 25;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.SteelBlue;
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel32.Location = new System.Drawing.Point(376, 186);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(137, 68);
            this.panel32.TabIndex = 25;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.SteelBlue;
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel33.Location = new System.Drawing.Point(133, 261);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(108, 68);
            this.panel33.TabIndex = 25;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.SteelBlue;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel34.Location = new System.Drawing.Point(248, 186);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(121, 68);
            this.panel34.TabIndex = 25;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.SteelBlue;
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel18.Location = new System.Drawing.Point(520, 36);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(132, 68);
            this.panel18.TabIndex = 24;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.SteelBlue;
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel19.Location = new System.Drawing.Point(520, 411);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(132, 68);
            this.panel19.TabIndex = 24;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.SteelBlue;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel20.Location = new System.Drawing.Point(659, 336);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(141, 68);
            this.panel20.TabIndex = 24;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.SteelBlue;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel21.Location = new System.Drawing.Point(248, 111);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(121, 68);
            this.panel21.TabIndex = 24;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.SteelBlue;
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel22.Location = new System.Drawing.Point(520, 261);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(132, 68);
            this.panel22.TabIndex = 24;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.SteelBlue;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel23.Location = new System.Drawing.Point(520, 186);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(132, 68);
            this.panel23.TabIndex = 24;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.SteelBlue;
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel24.Location = new System.Drawing.Point(659, 261);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(141, 68);
            this.panel24.TabIndex = 24;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.SteelBlue;
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel26.Location = new System.Drawing.Point(659, 111);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(141, 68);
            this.panel26.TabIndex = 24;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightCyan;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel10.Location = new System.Drawing.Point(949, 411);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(138, 68);
            this.panel10.TabIndex = 24;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.LightBlue;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel11.Location = new System.Drawing.Point(807, 411);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(135, 68);
            this.panel11.TabIndex = 24;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.LightCyan;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel12.Location = new System.Drawing.Point(949, 336);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(138, 68);
            this.panel12.TabIndex = 24;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.LightBlue;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel13.Location = new System.Drawing.Point(807, 336);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(135, 68);
            this.panel13.TabIndex = 24;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.LightCyan;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel14.Location = new System.Drawing.Point(949, 261);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(138, 68);
            this.panel14.TabIndex = 24;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.LightBlue;
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel15.Location = new System.Drawing.Point(807, 261);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(135, 68);
            this.panel15.TabIndex = 24;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.LightCyan;
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel16.Location = new System.Drawing.Point(949, 186);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(138, 68);
            this.panel16.TabIndex = 24;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightBlue;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel8.Location = new System.Drawing.Point(807, 111);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(135, 68);
            this.panel8.TabIndex = 24;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.LightCyan;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel9.Location = new System.Drawing.Point(949, 111);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(138, 68);
            this.panel9.TabIndex = 24;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightCyan;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel6.Location = new System.Drawing.Point(949, 36);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(138, 68);
            this.panel6.TabIndex = 24;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightBlue;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel7.Location = new System.Drawing.Point(807, 36);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(135, 68);
            this.panel7.TabIndex = 24;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Location = new System.Drawing.Point(248, 36);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(121, 68);
            this.panel3.TabIndex = 24;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel5.Location = new System.Drawing.Point(2, -1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 68);
            this.panel5.TabIndex = 24;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SteelBlue;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel4.Location = new System.Drawing.Point(133, 186);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(108, 68);
            this.panel4.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 408);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 42);
            this.label6.TabIndex = 22;
            this.label6.Text = "3.30-5.00";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 333);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 42);
            this.label5.TabIndex = 22;
            this.label5.Text = "2.00-3.30";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 258);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 42);
            this.label2.TabIndex = 22;
            this.label2.Text = "12.30-2.00";
            // 
            // linkLabel14
            // 
            this.linkLabel14.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel14.AutoSize = true;
            this.linkLabel14.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel14.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel14.LinkColor = System.Drawing.Color.Black;
            this.linkLabel14.Location = new System.Drawing.Point(133, 1);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Size = new System.Drawing.Size(86, 25);
            this.linkLabel14.TabIndex = 14;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "Sunday";
            this.linkLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel15
            // 
            this.linkLabel15.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel15.AutoSize = true;
            this.linkLabel15.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel15.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel15.LinkColor = System.Drawing.Color.Black;
            this.linkLabel15.Location = new System.Drawing.Point(248, 1);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Size = new System.Drawing.Size(89, 25);
            this.linkLabel15.TabIndex = 15;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "Monday";
            this.linkLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel16
            // 
            this.linkLabel16.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel16.AutoSize = true;
            this.linkLabel16.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel16.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel16.LinkColor = System.Drawing.Color.Black;
            this.linkLabel16.Location = new System.Drawing.Point(376, 1);
            this.linkLabel16.Name = "linkLabel16";
            this.linkLabel16.Size = new System.Drawing.Size(102, 25);
            this.linkLabel16.TabIndex = 16;
            this.linkLabel16.TabStop = true;
            this.linkLabel16.Text = " Tuesday";
            this.linkLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel17
            // 
            this.linkLabel17.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel17.AutoSize = true;
            this.linkLabel17.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel17.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel17.LinkColor = System.Drawing.Color.Black;
            this.linkLabel17.Location = new System.Drawing.Point(520, 1);
            this.linkLabel17.Name = "linkLabel17";
            this.linkLabel17.Size = new System.Drawing.Size(127, 25);
            this.linkLabel17.TabIndex = 17;
            this.linkLabel17.TabStop = true;
            this.linkLabel17.Text = "Wednesday";
            this.linkLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel18
            // 
            this.linkLabel18.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel18.AutoSize = true;
            this.linkLabel18.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel18.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel18.LinkColor = System.Drawing.Color.Black;
            this.linkLabel18.Location = new System.Drawing.Point(659, 1);
            this.linkLabel18.Name = "linkLabel18";
            this.linkLabel18.Size = new System.Drawing.Size(109, 25);
            this.linkLabel18.TabIndex = 18;
            this.linkLabel18.TabStop = true;
            this.linkLabel18.Text = " Thursday";
            this.linkLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel19
            // 
            this.linkLabel19.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel19.AutoSize = true;
            this.linkLabel19.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel19.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel19.LinkColor = System.Drawing.Color.Black;
            this.linkLabel19.Location = new System.Drawing.Point(807, 1);
            this.linkLabel19.Name = "linkLabel19";
            this.linkLabel19.Size = new System.Drawing.Size(90, 25);
            this.linkLabel19.TabIndex = 19;
            this.linkLabel19.TabStop = true;
            this.linkLabel19.Text = "   Friday";
            this.linkLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel20
            // 
            this.linkLabel20.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel20.AutoSize = true;
            this.linkLabel20.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel20.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel20.LinkColor = System.Drawing.Color.Black;
            this.linkLabel20.Location = new System.Drawing.Point(949, 1);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Size = new System.Drawing.Size(111, 25);
            this.linkLabel20.TabIndex = 20;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Text = "  Saturday";
            this.linkLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 42);
            this.label3.TabIndex = 22;
            this.label3.Text = "11.00-12.30";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 42);
            this.label4.TabIndex = 22;
            this.label4.Text = "9.30-11.00";
            // 
            // tsf1
            // 
            this.tsf1.BackColor = System.Drawing.Color.SteelBlue;
            this.tsf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tsf1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tsf1.Location = new System.Drawing.Point(133, 36);
            this.tsf1.Name = "tsf1";
            this.tsf1.Size = new System.Drawing.Size(108, 68);
            this.tsf1.TabIndex = 23;
            this.tsf1.Paint += new System.Windows.Forms.PaintEventHandler(this.tsf1_Paint);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 42);
            this.label1.TabIndex = 21;
            this.label1.Text = "8.00 -9.30";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(133, 111);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(108, 68);
            this.panel2.TabIndex = 24;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.LightBlue;
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel17.Location = new System.Drawing.Point(807, 186);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(135, 68);
            this.panel17.TabIndex = 24;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.SteelBlue;
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel27.Location = new System.Drawing.Point(659, 36);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(141, 68);
            this.panel27.TabIndex = 24;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.SteelBlue;
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel25.Location = new System.Drawing.Point(659, 186);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(141, 68);
            this.panel25.TabIndex = 24;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1121, 506);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Notice";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Snow;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.25352F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 57.74648F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1125, 502);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel3);
            this.tabPage3.Controls.Add(this.linkLabel11);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1121, 506);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Notes";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Snow;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1127, 502);
            this.tableLayoutPanel3.TabIndex = 11;
            // 
            // linkLabel11
            // 
            this.linkLabel11.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel11.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel11.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabel11.Location = new System.Drawing.Point(12, 69);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Size = new System.Drawing.Size(63, 25);
            this.linkLabel11.TabIndex = 9;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "Notes";
            this.linkLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // time
            // 
            this.time.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.time.ColumnCount = 3;
            this.time.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.53012F));
            this.time.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.46988F));
            this.time.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.time.Controls.Add(this.linkLabel6, 2, 0);
            this.time.Controls.Add(this.Class_time, 1, 1);
            this.time.Controls.Add(this.Room_no, 2, 1);
            this.time.Controls.Add(this.linkLabel5, 1, 0);
            this.time.Controls.Add(this.DAY, 0, 1);
            this.time.Controls.Add(this.linkLabel4, 0, 0);
            this.time.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.time.Location = new System.Drawing.Point(440, 166);
            this.time.Margin = new System.Windows.Forms.Padding(4);
            this.time.Name = "time";
            this.time.RowCount = 2;
            this.time.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.time.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.time.Size = new System.Drawing.Size(700, 123);
            this.time.TabIndex = 11;
            // 
            // linkLabel6
            // 
            this.linkLabel6.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel6.LinkColor = System.Drawing.Color.Black;
            this.linkLabel6.Location = new System.Drawing.Point(451, 1);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(145, 25);
            this.linkLabel6.TabIndex = 15;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "           Room no\r\n";
            this.linkLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Class_time
            // 
            this.Class_time.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Class_time.AutoSize = true;
            this.Class_time.BackColor = System.Drawing.Color.Transparent;
            this.Class_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Class_time.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Class_time.LinkColor = System.Drawing.Color.Black;
            this.Class_time.Location = new System.Drawing.Point(261, 62);
            this.Class_time.Name = "Class_time";
            this.Class_time.Size = new System.Drawing.Size(74, 25);
            this.Class_time.TabIndex = 17;
            this.Class_time.TabStop = true;
            this.Class_time.Text = "Theory\r\n";
            this.Class_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Room_no
            // 
            this.Room_no.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Room_no.AutoSize = true;
            this.Room_no.BackColor = System.Drawing.Color.Transparent;
            this.Room_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Room_no.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Room_no.LinkColor = System.Drawing.Color.Black;
            this.Room_no.Location = new System.Drawing.Point(451, 62);
            this.Room_no.Name = "Room_no";
            this.Room_no.Size = new System.Drawing.Size(128, 50);
            this.Room_no.TabIndex = 18;
            this.Room_no.TabStop = true;
            this.Room_no.Text = "DS-RoomNO\r\n\r\n";
            this.Room_no.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel5
            // 
            this.linkLabel5.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel5.LinkColor = System.Drawing.Color.Black;
            this.linkLabel5.Location = new System.Drawing.Point(261, 1);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(121, 25);
            this.linkLabel5.TabIndex = 14;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "             Time\r\n";
            this.linkLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DAY
            // 
            this.DAY.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.DAY.AutoSize = true;
            this.DAY.BackColor = System.Drawing.Color.Transparent;
            this.DAY.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DAY.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.DAY.LinkColor = System.Drawing.Color.Black;
            this.DAY.Location = new System.Drawing.Point(4, 62);
            this.DAY.Name = "DAY";
            this.DAY.Size = new System.Drawing.Size(108, 25);
            this.DAY.TabIndex = 16;
            this.DAY.TabStop = true;
            this.DAY.Text = "Day - Time";
            this.DAY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // linkLabel4
            // 
            this.linkLabel4.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel4.LinkColor = System.Drawing.Color.Black;
            this.linkLabel4.Location = new System.Drawing.Point(4, 1);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(157, 25);
            this.linkLabel4.TabIndex = 13;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "                      Day\r\n";
            this.linkLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel3.LinkColor = System.Drawing.Color.Black;
            this.linkLabel3.Location = new System.Drawing.Point(263, 132);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(70, 20);
            this.linkLabel3.TabIndex = 12;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Faculty\r\n";
            this.linkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // Teacher_email
            // 
            this.Teacher_email.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Teacher_email.AutoSize = true;
            this.Teacher_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teacher_email.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Teacher_email.LinkColor = System.Drawing.Color.Black;
            this.Teacher_email.Location = new System.Drawing.Point(250, 95);
            this.Teacher_email.Name = "Teacher_email";
            this.Teacher_email.Size = new System.Drawing.Size(158, 20);
            this.Teacher_email.TabIndex = 11;
            this.Teacher_email.TabStop = true;
            this.Teacher_email.Text = "teacher@email.com\r\n";
            this.Teacher_email.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Teacher_email.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // Teacher_name
            // 
            this.Teacher_name.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.Teacher_name.AutoSize = true;
            this.Teacher_name.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teacher_name.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.Teacher_name.LinkColor = System.Drawing.Color.Black;
            this.Teacher_name.Location = new System.Drawing.Point(249, 55);
            this.Teacher_name.Name = "Teacher_name";
            this.Teacher_name.Size = new System.Drawing.Size(154, 29);
            this.Teacher_name.TabIndex = 10;
            this.Teacher_name.TabStop = true;
            this.Teacher_name.Text = "Teacher Name\r\n";
            this.Teacher_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Teacher_pic_box
            // 
            this.Teacher_pic_box.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Teacher_pic_box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Teacher_pic_box.Image = global::University_Management_System.Properties.Resources.user;
            this.Teacher_pic_box.Location = new System.Drawing.Point(12, 55);
            this.Teacher_pic_box.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Teacher_pic_box.Name = "Teacher_pic_box";
            this.Teacher_pic_box.Size = new System.Drawing.Size(231, 227);
            this.Teacher_pic_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Teacher_pic_box.TabIndex = 9;
            this.Teacher_pic_box.TabStop = false;
            // 
            // courseName
            // 
            this.courseName.ActiveLinkColor = System.Drawing.Color.DarkSlateGray;
            this.courseName.AutoSize = true;
            this.courseName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.courseName.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.courseName.LinkColor = System.Drawing.Color.Black;
            this.courseName.Location = new System.Drawing.Point(17, 17);
            this.courseName.Name = "courseName";
            this.courseName.Size = new System.Drawing.Size(181, 25);
            this.courseName.TabIndex = 9;
            this.courseName.TabStop = true;
            this.courseName.Text = "Course Name [sec]\r\n";
            this.courseName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Minimize
            // 
            this.Minimize.BackColor = System.Drawing.Color.White;
            this.Minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimize.FlatAppearance.BorderSize = 0;
            this.Minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minimize.ForeColor = System.Drawing.Color.White;
            this.Minimize.Image = global::University_Management_System.Properties.Resources.icons8_minus_20;
            this.Minimize.Location = new System.Drawing.Point(1956, -2);
            this.Minimize.Margin = new System.Windows.Forms.Padding(0);
            this.Minimize.Name = "Minimize";
            this.Minimize.Size = new System.Drawing.Size(47, 43);
            this.Minimize.TabIndex = 9;
            this.Minimize.UseVisualStyleBackColor = false;
            this.Minimize.Click += new System.EventHandler(this.Minimize_Click);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.MistyRose;
            this.Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Image = global::University_Management_System.Properties.Resources.icons8_cancel_20;
            this.Exit.Location = new System.Drawing.Point(2003, -2);
            this.Exit.Margin = new System.Windows.Forms.Padding(0);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(47, 43);
            this.Exit.TabIndex = 8;
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Tsf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1478, 1055);
            this.Controls.Add(this.teacher_info);
            this.Controls.Add(this.Minimize);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Tsf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tsf";
            this.Load += new System.EventHandler(this.Tsf_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.teacher_info.ResumeLayout(false);
            this.teacher_info.PerformLayout();
            this.notice.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.time.ResumeLayout(false);
            this.time.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Teacher_pic_box)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel Grade_link;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.LinkLabel Registration_link;
        private System.Windows.Forms.LinkLabel Course_and_result_link;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Minimize;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel teacher_info;
        private System.Windows.Forms.LinkLabel courseName;
        private System.Windows.Forms.PictureBox Teacher_pic_box;
        private System.Windows.Forms.LinkLabel Teacher_email;
        private System.Windows.Forms.LinkLabel Teacher_name;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.TableLayoutPanel time;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel Room_no;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel DAY;
        private System.Windows.Forms.LinkLabel Class_time;
        private System.Windows.Forms.TabControl notice;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.LinkLabel Profile_link;
        private System.Windows.Forms.Button Back_Button;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.LinkLabel linkLabel16;
        private System.Windows.Forms.LinkLabel linkLabel17;
        private System.Windows.Forms.LinkLabel linkLabel18;
        private System.Windows.Forms.LinkLabel linkLabel19;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel tsf1;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
    }
}