﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace University_Management_System
{
    internal partial class ProfileShow : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=UNIVERSITY_MANAGEMENT_SYSTEM;Integrated Security=True");

        //public string login_id;
        Student student;
        public ProfileShow(Student students)
        {
            this.student = students;
            InitializeComponent();
            
        }

        private void ProfileShow_Load(object sender, EventArgs e)
        {

            full_name_lbl.Text = student.FirstName +" "+student.LastName;
            label1.Text = "Student ID :  " + student.ID;
            label2.Text = "CGPA :  " + student.CGPA;
            label3.Text = "Credit :  " + student.CreditComplete;
            label4.Text = "Email :  " + student.Email;
            label5.Text = "NID :  " + student.NID;
            label6.Text = "Father Name :  " + student.FatherName;
            label7.Text = "Mother Name : " +student.MotherName;
            label8.Text = "Mobile :  " + student.Mobile;
            label9.Text = "Date of Birth :  " + student.DOB.Day +"-"+student.DOB.Month+"-"+student.DOB.Year;
            program.Text = "Program :  " + student.Programs.ProgramName;
            City.Text = "City : " + student.Address.City;
            Area.Text = "Area : " + student.Address.Area;
            House.Text = "House : " + student.Address.House;
            Road.Text = "Road : " + student.Address.Road;

            
            Person_photo.Image = Image.FromStream(student.Images);
            connection.Close();

            //var query1 = "select * from STUDENT where Student_ID='" + student.ID + "'";
            //SqlCommand cmd = new SqlCommand(query1, connection); //query executed
            //connection.Open();

            //var reader = cmd.ExecuteReader();
            //while(reader.Read()==true)
            //{

            //    byte[] img = (byte[])reader["Photo"];
            //    if(img == null)
            //    {
            //        Person_photo.Image = null;
            //    }
            //    else
            //    {
            //        MemoryStream ms = new MemoryStream(img);
            //        Person_photo.Image = Image.FromStream(ms);
            //    }      
            //}
            //connection.Close();
        }
        private void Back_Button_Click(object sender, EventArgs e)
        {
            Student_dashboard sd = new Student_dashboard(student);
            this.Hide();
            sd.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query1 = "update LOGIN set password='" + pass_change_box.Text + "' where user_id= '"+student.ID+"'";

            SqlCommand cmd = new SqlCommand(query1, connection);
            connection.Open();
            if(connection.State == ConnectionState.Open)
            {
                int result = cmd.ExecuteNonQuery();
                if(result>0)
                {
                    MessageBox.Show("Update Successful!");
                }
                connection.Close();
            }

            string query2 = "update STUDENT set Password='" + pass_change_box.Text + "' where Student_ID= '" + student.ID + "'";

            SqlCommand cmd2 = new SqlCommand(query2, connection);
            connection.Open();
            if (connection.State == ConnectionState.Open)
            {
                int result1 = cmd2.ExecuteNonQuery();
                if (result1 > 0)
                {
                    MessageBox.Show("Update Successful!");
                }
                connection.Close();
            }

        }
        private void Course_and_result_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Course_result_form result = new Course_result_form(student);
            this.Hide();
            result.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
