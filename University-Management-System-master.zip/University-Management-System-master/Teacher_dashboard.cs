﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace University_Management_System
{
    internal partial class Teacher_dashboard : Form
    {
        SqlConnection connection = new SqlConnection("Data Source=SAQLAN-XAMI;Initial Catalog=UNIVERSITY_MANAGEMENT_CITY;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-NHRHLTK;Initial Catalog=data;Integrated Security=True;");

        public static Teacher teacher1;
        public Teacher_dashboard(Teacher teach11)
        {
            teacher1 = teach11;
            InitializeComponent();
        }

        Section[] sunday = new Section[5];
        Section[] monday = new Section[5];
        private void Teacher_dashboard_Load(object sender, EventArgs e)
        {
            teacher1.getRegisteredCourses(teacher1.ID);

            int count1 = 0; int count2 = 0;

            string[] sunday_tuesday = new string[] { "", "", "", "", "" };
            string[] monday_thursday = new string[] { "", "", "", "", "" };

            for(int i=0; i<teacher1.RegisteredCourses.Length; i++)
            {
                sunday_tuesday[i] = "";
                monday_thursday[i] = "";

                if (teacher1.RegisteredCourses[i].Schedules.ScheduleDay == "sunday-tuesday")
                {
                    sunday[count1] = new Section(teacher1.RegisteredCourses[i].ID);
                    sunday_tuesday[count1] = teacher1.RegisteredCourses[i].Courses.CourseName + " [" + teacher1.RegisteredCourses[i].SectionName + "] " + teacher1.RegisteredCourses[i].RoomNo;
                    count1++;
                }
                else if (teacher1.RegisteredCourses[i].Schedules.ScheduleDay == "monday-wednesday")
                {
                    monday[count2] = new Section(teacher1.RegisteredCourses[i].ID);
                    monday_thursday[count2] = teacher1.RegisteredCourses[i].Courses.CourseName + " [" + teacher1.RegisteredCourses[i].SectionName + "] " + teacher1.RegisteredCourses[i].RoomNo;
                    count2++;
                }
            }

            linkSunday1.Text = linkTuesday1.Text = sunday_tuesday[0];
            linkSunday2.Text = linkTuesday2.Text = sunday_tuesday[1];
            linkSunday3.Text = linkTuesday3.Text = sunday_tuesday[2];
            linkSunday4.Text = linkTuesday4.Text = sunday_tuesday[3];
            linkSunday5.Text = linkTuesday5.Text = sunday_tuesday[4];

            linkMonday1.Text = linkwednesday1.Text = monday_thursday[0];
            linkMonday2.Text = linkwednesday2.Text = monday_thursday[1];
            linkMonday3.Text = linkwednesday3.Text = monday_thursday[2];
            linkMonday4.Text = linkwednesday4.Text = monday_thursday[3];
            linkMonday5.Text = linkwednesday5.Text = monday_thursday[4];

            Profile_link.Text = teacher1.FirstName;

            panel5.Hide();
            panel6.Hide();
            panel7.Hide();
            panel8.Hide();
            panel9.Hide();
            panel10.Hide();


            for (int i = 0; i < teacher1.RegisteredCourses.Length; i++)
            {
                if (!comboBox1.Items.Contains(teacher1.RegisteredCourses[i].Semester))
                {
                    comboBox1.Items.Add(teacher1.RegisteredCourses[i].Semester);
                }
                if (i == 0)
                {
                    course1.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room1.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time1.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                    panel5.Show();
                }
                else if (i == 1)
                {
                    panel6.Show();
                    course2.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room2.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time2.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 2)
                {
                    panel7.Show();
                    course3.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room3.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time3.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 3)
                {
                    panel8.Show();
                    course4.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room4.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time4.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 4)
                {
                    panel9.Show();
                    course5.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room5.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time5.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                }
                else if (i == 5)
                {
                    panel10.Show();
                    course6.Text = teacher1.RegisteredCourses[i].Courses.CourseName;
                    room6.Text = "Room:-  " + teacher1.RegisteredCourses[i].RoomNo;
                    time6.Text = "Time:-  " + teacher1.RegisteredCourses[i].Schedules.ScheduleTime;
                }

            }
        }

        private void course5_Click(object sender, EventArgs e)
        {

        }

        private void Profile_link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            teacher_profile pfs = new teacher_profile(teacher1);
            this.Hide();
            pfs.Show();
        }

        private void Back_Button_Click(object sender, EventArgs e)
        {
            Login1 log = new Login1();
            this.Hide();
            log.Show();
        }
    }
}
